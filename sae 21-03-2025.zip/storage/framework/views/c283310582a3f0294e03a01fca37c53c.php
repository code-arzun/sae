<?php $__env->startSection('specificpagestyles'); ?>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.14/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.14/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between mb-3">
    <div>
        <h2><?php echo e($title); ?></h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-default-icon">
                <?php echo $__env->make('warehouse.delivery.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('input.do')); ?>">Input</a></li>
            </ol>
        </nav>
    </div>
</div>

<div class="row">
    <div class="col-lg-6 col-md-12">
    <!-- Produk -->
        <?php echo $__env->make('warehouse.delivery.input.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    
    <!-- Cart -->
    <div class="col-lg-6 col-md-12 mb-5">
        <?php echo $__env->make('warehouse.delivery.input.cart', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<script>
    $('#order_date').datepicker({
        uiLibrary: 'bootstrap4',
        // format: 'dd-mm-yyyy'
        format: 'yyyy-mm-dd'
        // https://gijgo.com/datetimepicker/configuration/format
    });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/input.blade.php ENDPATH**/ ?>