<!-- Tambahkan Bootstrap JS -->




<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between mb-3">
    <div>
        <h2><?php echo e($title); ?></h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-default-icon">
                <?php echo $__env->make('marketing.salesorder.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('so.orderDetails', $order->id)); ?>">Detail</a></li>
                <li class="breadcrumb-item active" aria-current="page"><b><?php echo e($order->invoice_no); ?></b>_<?php echo e($order->customer->NamaLembaga); ?>_<?php echo e($order->customer->NamaCustomer); ?>_<?php echo e($order->customer->employee->name); ?></li>
            </ol>
        </nav>
    </div>
    <div>
        <!-- Update status button -->
        <?php if($order->order_status == 'Menunggu persetujuan'): ?>
        <a href="#" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#confirmation<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>"><i class="fa fa-info-circle me-2"></i><span>Perbarui Status Sales Order</span></a>
        <?php endif; ?>
        <?php echo $__env->make('marketing.salesorder.data.status-update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<!-- Informasi Umum -->
<div class="mb-5">
    <h4 class="mb-3">Informasi Umum</h4>
    <div class="card">
        <div class="card-body">
            <div class="row justify-content-between">
                <div class="col d-flex flex-column mb-3">
                    <label class="mb-2">Tanggal Pemesanan</label>
                    <h5><?php echo e(Carbon\Carbon::parse($order->order_date)->translatedformat('l, d F Y')); ?></h5>
                </div>
                <div class="col col-md-1 d-flex flex-column mb-3">
                    <label class="mb-2">Nomor SO</label>
                    <div>
                        <span class="badge <?php echo e(strpos($order->invoice_no, '-R') !== false ? 'bg-primary' : (strpos($order->invoice_no, '-H') !== false ? 'bg-danger' : 
                                (strpos($order->invoice_no, '-RS') !== false ? 'bg-success' : (strpos($order->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary')))); ?>">
                            <?php echo e($order->invoice_no); ?>

                        </span>
                    </div>
                </div>
                <div class="col d-flex flex-column mb-3">
                    <label class="mb-2">Metode Pembayaran</label>
                    <h5> <?php echo e($order->payment_method); ?></h5>
                </div>
                <div class="col d-flex flex-column mb-3">
                    <label class="mb-2">Status </label>
                    <div>
                        <span class="badge <?php echo e(strpos($order->order_status, 'Menunggu persetujuan') !== false ? 'bg-warning' : (strpos($order->order_status, 'Disetujui') !== false ? 'bg-success' : 
                                (strpos($order->order_status, 'Dalam pengiriman') !== false ? 'bg-success' : 'bg-secondary'))); ?>">
                            <?php echo e($order->order_status); ?>

                        </span>
                    </div>
                </div>
                <div class="col d-flex flex-column mb-3">
                    <label class="mb-2">Nama Lembaga</label>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Customer"
                        href="<?php echo e(route('customers.show', $order->customer->id)); ?>">
                        <h5><?php echo e($order->customer->NamaLembaga); ?></h5>
                    </a>
                </div>
                <div class="col d-flex flex-column mb-3">
                    <label class="mb-2">Nama Customer</label>
                    <a data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Customer"
                        href="<?php echo e(route('customers.show', $order->customer->id)); ?>">
                        <h5><?php echo e($order->customer->NamaCustomer); ?></h5>
                    </a>
                </div>
                <div class="col col-md-1 d-flex flex-column mb-3">
                    <label class="mb-2">Jabatan</label>
                    
                    <h5><?php echo e($order->customer->Jabatan); ?></h5>
                </div>
                <div class="col d-flex flex-column">
                    <label class="mb-2">Sales</label>
                    <h5><?php echo e($order->customer->employee->name); ?></h5>
                </div>
            </div>
        </div>
    </div>
</div>

<div>
    <!-- Navigation Tabs -->
    <ul class="nav nav-tabs mb-3" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="home-tab" data-bs-toggle="tab" href="#home" role="tab"><h5>Sales Order</h5></a>
        </li>
        <?php if($order->order_status == 'Disetujui' || $order->order_status == 'Selesai' ): ?>
        <li class="nav-item">
            <a class="nav-link" id="delivery-tab" data-bs-toggle="tab" href="#delivery" role="tab"><h5>Delivery Order</h5></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="collection-tab" data-bs-toggle="tab" href="#coll" role="tab"><h5>Collection</h5></a>
        </li>
        <?php endif; ?>
    </ul>
    <!-- Content -->
    <div class="tab-content" id="myTabContent">
        <!-- Sales Order -->
        <div class="tab-pane fade show active" id="home" role="tabpanel">
            <?php echo $__env->make('marketing.salesorder.details.so', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Delivery Order -->
        <div class="tab-pane fade" id="delivery" role="tabpanel">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Delivery Order</h4>
                    </div>

                    <?php
                        $remainingAmount = $order->sub_total - $deliveries->sum('sub_total');
                    ?>
            
                    <?php if($remainingAmount > 0 && auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                    <div>
                        <a href="<?php echo e(route('input.do')); ?>"
                            class="btn bg-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Buat Delivery Order">
                            <i class="fa fa-plus me-2" aria-hidden="true"></i>Buat Delivery Order 
                        </a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap mb-3">
                        <thead>
                            <tr>
                                <th width="3px">No.</th>
                                <th width="500px">Produk</th>
                                <th>Kategori</th>
                                <th>Jumlah</th>
                                <th>Belum Dikirim</th>
                                <th>Siap Kirim</th>
                                <th>Dalam Pengiriman</th>
                                <th>Terkirim</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><b><?php echo e($item->product->product_name); ?></b></td>
                                <td><?php echo e($item->product->category->name); ?></td>
                                <td class="text-center"><span class="badge bg-purple me-2"><?php echo e(number_format($item->quantity)); ?></span>
                                    <?php echo e($item->product->category->productunit->name); ?>

                                </td>
                                <td class="text-center">
                                    <?php if($item->quantity === $item->delivered): ?>
                                    <?php else: ?>
                                    <span class="badge bg-danger me-2"><?php echo e(number_format($item->to_send)); ?></span>
                                    <?php echo e($item->product->category->productunit->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($item->quantity === $item->delivered): ?>
                                    <?php else: ?>
                                    <span class="badge bg-warning me-2"><?php echo e(number_format($item->ready_to_send)); ?></span>
                                    <?php echo e($item->product->category->productunit->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($item->quantity === $item->delivered): ?>
                                    <?php else: ?>
                                    <span class="badge bg-primary me-2"><?php echo e(number_format($item->sent)); ?></span>
                                    <?php echo e($item->product->category->productunit->name); ?>

                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><span class="badge bg-success me-2"><?php echo e(number_format($item->delivered)); ?></span>
                                    <?php echo e($item->product->category->productunit->name); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap mb-3">
                        <thead>
                            <tr>
                                <th>Pengiriman ke-</th>
                                <th>Tanggal DO</th>
                                <th>No. DO</th>
                                <th>Dokumen</th>
                                <th>Total Produk</th>
                                <th>Total</th>
                                <th>Terpacking</th>
                                <th>Dikirim</th>
                                <th>Terkirim</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($delivery->delivery_date)->translatedformat('l, d F Y')); ?></td>
                                <td>
                                    <a class="badge badge-primary" href="<?php echo e(route('do.deliveryDetails', $delivery->id)); ?>" 
                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail"><?php echo e($delivery->invoice_no); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('do.invoiceDownload', $delivery->id)); ?>"
                                        class="btn bg-warning me-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak Dokumen">
                                        <i class="fa fa-print me-0" aria-hidden="true"></i> 
                                    </a>
                                </td>
                                <td><b class="mr-1"><?php echo e(number_format($delivery->total_products)); ?></b> <?php echo e($item->product->category->productunit->name); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format($delivery->sub_total)); ?></td>
                                <td class="text-center"><?php echo e($delivery->packed_at ? Carbon\Carbon::parse($delivery->packed_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
                                <td class="text-center"><?php echo e($delivery->sent_at ? Carbon\Carbon::parse($delivery->sent_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
                                <td class="text-center"><?php echo e($delivery->delivered_at ? Carbon\Carbon::parse($delivery->delivered_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <table class="table text-center">
                        <thead>
                            <tr>
                                <th>Jumlah Pengiriman</th>
                                <th>Total Produk Terkirim</th>
                                <th>Subtotal Barang Terkirim</th>
                                <th>Total Produk Belum dikirim</th>
                                <th>Subtotal Belum dikirim</th>
                            </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td><span class="badge bg-warning me-1"><?php echo e($deliveries->count('order_id')); ?></span> kali</td>
                            <td><span class="badge bg-success"><?php echo e($deliveries->sum('total_products')); ?></span></td>
                            <td><span class="badge bg-primary">Rp <?php echo e(number_format($deliveries->sum('sub_total'))); ?></span></td>
                            <td>
                                <span class="badge bg-danger">
                                    <?php echo e($order->total_products - $deliveries->sum('total_products')); ?>

                                </span>
                            </td>
                            <td><span class="badge bg-danger">Rp <?php echo e(number_format($order->sub_total - $deliveries->sum('sub_total'))); ?></span></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap mb-3">
                        <thead>
                            <tr>
                                <th>No.</th>
                                <th>Produk</th>
                                <th>Jumlah</th>
                                <th>Pengiriman ke-1</th>
                                <th>Pengiriman ke-2</th>
                                <th>Pengiriman ke-3</th>
                                <th>Belum dikirim</th>
                            </tr>
                        </thead>
                        <tbody class="light-data">
                            <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td><b><?php echo e($item->product->product_name); ?></b>
                                        <p><?php echo e($item->product->category->name); ?></p>
                                    </td>
                                    <td class="text-center">
                                        <b class="mr-1"><?php echo e(number_format($item->quantity)); ?></b> 
                                    </td>
                                    
                                    <?php
                                        // Ambil semua delivery terkait dengan order dan produk saat ini
                                        $deliveries = $deliveryDetails->where('product_id', $item->product_id);
                                        $maxDeliveries = 3; // Misal kita ingin menampilkan 3 pengiriman
                                    ?>
                                    
                                    <?php if($deliveries->count() > 0): ?>
                                        <?php $__currentLoopData = $deliveries->take($maxDeliveries); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <td class="text-center">
                                                <b class="mr-1"><?php echo e(number_format($delivery->quantity)); ?></b> 
                                            </td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <!-- Jika jumlah pengiriman kurang dari maksimal, tampilkan kolom kosong -->
                                        <?php for($i = $deliveries->count(); $i < $maxDeliveries; $i++): ?>
                                            <td class="text-center">-</td>
                                        <?php endfor; ?>
                                    <?php else: ?>
                                        <!-- Jika tidak ada pengiriman, tampilkan kolom kosong -->
                                        <?php for($i = 0; $i < $maxDeliveries; $i++): ?>
                                            <td class="text-center">-</td>
                                        <?php endfor; ?>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- Collection -->
        <div class="tab-pane fade" id="coll" role="tabpanel">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Collection</h4>
                    </div>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table text-center">
                        <thead>
                            <tr>
                                <th>Subtotal</th>
                                <th>Diskon</th>
                                <th>Grand Total</th>
                                <th>Total Tagihan</th>
                                <th>Tagihan</th>
                                <th>Telah dibayar</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td><span class="badge bg-success">Rp <?php echo e(number_format($order->sub_total)); ?></td>
                                <td><span class="badge bg-warning"><?php echo e(number_format($order->discount_percent, 2)); ?>%</span> <span class="badge bg-danger">Rp <?php echo e(number_format($order->discount_rp)); ?></span></td>
                                <td><span class="badge bg-primary">Rp <?php echo e(number_format($order->grandtotal)); ?></td>
                                <td><span class="badge bg-purple">Rp <?php echo e(number_format($order->sub_total)); ?></td>
                                <td><span class="badge bg-danger">Rp <?php echo e(number_format($order->due)); ?></td>
                                <td><span class="badge bg-success">Rp <?php echo e(number_format($order->pay)); ?></td>
                                <td class="text-center">
                                    <?php if($order->payment_status === 'Lunas'): ?>
                                        <span class="badge bg-success"><?php echo e($order->payment_status); ?></span>
                                    <?php elseif($order->payment_status === 'Belum Lunas'): ?>
                                        <span class="badge bg-warning"><?php echo e($order->payment_status); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-danger"><?php echo e($order->payment_status); ?></span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="dt-responsive table-responsive">
                    <table class="table table-striped table-bordered nowrap mb-3">
                        <thead>
                            <tr>
                                <th>Pembayaran ke-</th>
                                <th>Tanggal Coll</th>
                                <th>No. Coll</th>
                                <th>Dokumen</th>
                                <th>Dibayarkan</th>
                                <th>Nett</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="text-center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(Carbon\Carbon::parse($collection->collection_date)->translatedformat('l, d F Y')); ?></td>
                                <td>
                                    <a class="badge badge-primary" href="<?php echo e(route('collection.details', $collection->id)); ?>" 
                                        data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail"><?php echo e($collection->invoice_no); ?>

                                    </a>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('collection.invoiceDownload', $collection->id)); ?>"
                                        class="btn bg-warning me-2" data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak Dokumen">
                                        <i class="fa fa-print me-0" aria-hidden="true"></i> 
                                    </a>
                                </td>
                                <td class="text-end">Rp <?php echo e(number_format($collection->pay)); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format($collection->grandtotal)); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('components.preview-img-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/details.blade.php ENDPATH**/ ?>