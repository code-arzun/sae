<!-- Pulang -->
<?php if(isset($attendance) && $attendance->status == 'Hadir' && !$attendance->pulang): ?>
<div class="modal fade" id="attendanceModal" tabindex="-1" role="dialog" aria-labelledby="attendanceModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="attendanceModalLabel">Form Absensi Pulang</h5>
                <span><?php echo e(Carbon\Carbon::parse()->translatedFormat('l, d F Y')); ?></span>
            </div>
            <div class="modal-body">
                <!-- Tampilkan Data Kehadiran yang Sudah Diisi -->
                
                <!-- Form Pulang (muncul setelah status Hadir dan absensi disubmit) -->
                <form id="checkoutForm" action="<?php echo e(route('attendance.update', ['attendance' => $attendance->id])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <!-- Input Pulang -->
                    <div class="form-group col-md-2" id="timepickerDiv">
                        <label for="pulang" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Jam Pulang</label>
                        <input id="pulang" type="time" class="form-control <?php $__errorArgs = ['pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pulang" value="<?php echo e(old('pulang')); ?>" required>
                        <?php $__errorArgs = ['pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- Jurnal Harian Kerja -->
                    <div class="form-group col-md" id="work_journal">
                        <label for="work_journal" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Worksheet Harian</label>
                        <textarea class="form-control <?php $__errorArgs = ['work_journal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="work_journal" name="work_journal" rows="10" value="<?php echo e(old('work_journal')); ?>" required></textarea>
                        <?php $__errorArgs = ['work_journal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            Worksheet harian belum diisi!
                        </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                </div>
                <div class="modal-footer">
                    <a href="<?php echo e(route('dashboard')); ?>"><span class="badge bg-warning">Isi Nanti</span></a>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/attendance/checkout.blade.php ENDPATH**/ ?>