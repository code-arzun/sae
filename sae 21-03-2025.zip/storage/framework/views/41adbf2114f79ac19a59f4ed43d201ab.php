<?php $__env->startSection('container'); ?>
<div class="card-body">
    <div class="d-flex justify-content-between align-items-start mb-4">
      <h1>Login</h1>
      <img src="../assets/images/logo.png" alt="img" class="logo">
    </div>
    <form action="<?php echo e(route('login')); ?>" method="POST">
        <?php echo csrf_field(); ?>
    <div class="form-group mb-4">
      <label class="form-label">Username</label>
      <input class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="username" placeholder="Masukkan username" value="<?php echo e(old('username')); ?>" autocomplete="off" required autofocus>
      
    </div>
    <div class="form-group mb-4">
      <label class="form-label">Password</label>
      <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password" placeholder="Masukkan password" required>
      
    </div>
    <?php if($errors->has('username') || $errors->has('password')): ?>
        <div class="text-danger">Masukkan username dan password dengan benar!</div>
    <?php endif; ?>
    
    <div class="d-grid mt-5">
        <button type="submit" class="btn btn-primary">Login</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('auth.body.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/auth/login.blade.php ENDPATH**/ ?>