<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between mb-3">
        <div>
            <h2><?php echo e($title); ?></h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-default-icon">
                    <?php echo $__env->make('warehouse.delivery.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('do.index')); ?>">Detail</a></li>
                </ol>
            </nav>
        </div>
        <div>
            
        </div>
    </div>
    <div class="mb-5">
        <h4 class="mb-3">Informasi Umum</h4>
        <div class="card">
            <div class="card-body">
                <div class="row justify-content-between">
                    <div class="col d-flex flex-column mb-3">
                        <label class="mb-2">Tanggal Pemesanan</label>
                        <h5><?php echo e(Carbon\Carbon::parse($delivery->salesorder->order_date)->translatedformat('l, d F Y')); ?></h5>
                    </div>
                    <div class="col col-md-1 d-flex flex-column mb-3">
                        <label class="mb-2">Nomor SO</label>
                        <span class="badge <?php echo e(strpos($delivery->salesorder->invoice_no, '-R') !== false ? 'bg-primary' : (strpos($delivery->salesorder->invoice_no, '-H') !== false ? 'bg-danger' : 
                                (strpos($delivery->salesorder->invoice_no, '-RS') !== false ? 'bg-success' : (strpos($delivery->salesorder->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary')))); ?>">
                            <?php echo e($delivery->salesorder->invoice_no); ?>

                        </span>
                    </div>
                    <div class="col d-flex flex-column mb-3">
                        <label class="mb-2">Metode Pembayaran</label>
                        <h5> <?php echo e($delivery->salesorder->payment_method); ?></h5>
                    </div>
                    <div class="col d-flex flex-column mb-3">
                        <label class="mb-2">Status </label>
                        <span class="badge <?php echo e(strpos($delivery->salesorder->order_status, 'Menunggu persetujuan') !== false ? 'bg-warning' : (strpos($delivery->salesorder->order_status, 'Disetujui') !== false ? 'bg-success' : 
                                (strpos($delivery->salesorder->order_status, 'Dalam pengiriman') !== false ? 'bg-success' : 'bg-secondary'))); ?>">
                            <?php echo e($delivery->salesorder->order_status); ?>

                        </span>
                    </div>
                    <div class="col d-flex flex-column mb-3">
                        <label class="mb-2">Nama Lembaga</label>
                        <a data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Customer"
                            href="<?php echo e(route('customers.show', $delivery->salesorder->customer->id)); ?>">
                            <h5><?php echo e($delivery->salesorder->customer->NamaLembaga); ?></h5>
                        </a>
                    </div>
                    <div class="col d-flex flex-column mb-3">
                        <label class="mb-2">Nama Customer</label>
                        <a data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Customer"
                            href="<?php echo e(route('customers.show', $delivery->salesorder->customer->id)); ?>">
                            <h5><?php echo e($delivery->salesorder->customer->NamaCustomer); ?></h5>
                        </a>
                    </div>
                    <div class="col col-md-1 d-flex flex-column mb-3">
                        <label class="mb-2">Jabatan</label>
                        <span class="badge bg-secondary"><?php echo e($delivery->salesorder->customer->Jabatan); ?></span>
                    </div>
                    <div class="col d-flex flex-column">
                        <label class="mb-2">Sales</label>
                        <h5><?php echo e($delivery->salesorder->customer->employee->name); ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        
        <div class="col-lg-12">
            <div class="row">
                
                
                <div class="col-md">
                    <div class="row">
                        <div class="col-lg-12 mb-3">
                            <div class="d-flex justify-content-between align-items-center list-action">
                                <a href="<?php echo e(url()->previous()); ?>"
                                   class="badge bg-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Kembali">
                                   <i class="fa fa-arrow-left"></i>
                                </a>
                                <?php if($deliveries->delivery_status == 'Siap dikirim'): ?>
                                <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin', 'Admin Gudang'])): ?>
                                <div class="d-flex ml-auto">
                                    <form action="<?php echo e(route('do.sentStatus')); ?>" method="POST" class="mr-2">
                                        <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?php echo e($deliveries->id); ?>">
                                        <button type="submit" class="btn bg-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Kirim"><b>Kirim</b></button>
                                    </form>
                                </div>
                                <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <div class="header-title">
                        <h4 class="card-title">Informasi Detail Pesanan</h4>
                    </div>
                </div>

                <div class="card-body">
                    <div class="row align-items-top">
                        <div class="form-group col-md-3">
                            <label>Tanggal DO</label> <br>
                                <span class="badge bg-primary"><?php echo e(Carbon\Carbon::parse($deliveries->delivery_date)->translatedformat('l, d F Y')); ?></span>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Nomor</label> <br>
                                <span class="badge 
                                    <?php echo e(strpos($deliveries->invoice_no, 'DOR') !== false ? 'badge-primary' : 
                                    (strpos($deliveries->invoice_no, 'DOH') !== false ? 'badge-danger' : 
                                    (strpos($deliveries->invoice_no, 'DORS') !== false ? 'badge-success' : 
                                    (strpos($deliveries->invoice_no, 'DOHS') !== false ? 'badge-warning' : 'badge-secondary')))); ?>">
                                    <?php echo e($deliveries->invoice_no); ?>

                                </span>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Status </label> <br>
                                <span class="badge 
                                    <?php echo e(strpos($deliveries->delivery_status, 'Siap dikirim') !== false ? 'badge-warning' : 
                                       (strpos($deliveries->delivery_status, 'Dikirim') !== false ? 'badge-primary' : 
                                       (strpos($deliveries->delivery_status, 'Terkirim') !== false ? 'badge-success' : 'badge-secondary'))); ?>">
                                    <?php echo e($deliveries->delivery_status); ?>

                                </span>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Nomor SO</label> <br>
                            <a class="badge 
                                    <?php echo e(strpos($deliveries->salesorder->invoice_no, 'SOR') !== false ? 'badge-primary' : 
                                    (strpos($deliveries->salesorder->invoice_no, 'SOH') !== false ? 'badge-danger' : 
                                    (strpos($deliveries->salesorder->invoice_no, 'SORS') !== false ? 'badge-success' : 
                                    (strpos($deliveries->salesorder->invoice_no, 'SOHS') !== false ? 'badge-warning' : 'badge-secondary')))); ?>" 
                                    href="<?php echo e(route('so.orderDetails', $deliveries->salesorder->id)); ?>" 
                                    data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail">
                                    <?php echo e($deliveries->salesorder->invoice_no); ?>

                            </a>
                        </div>
                        
                        <div class="form-group col-md-3">
                            <label>Sales</label> <br>
                                <span class="badge bg-primary">
                                <?php echo e($deliveries->salesorder->customer->employee->name); ?>

                                </span>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Nama Customer</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->NamaCustomer); ?>" readonly>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Jabatan</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->Jabatan); ?>" readonly>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Telp.</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->TelpCustomer); ?>" readonly>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Alamat</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->AlamatCustomer); ?>" readonly>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Nama Lembaga</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->NamaLembaga); ?>" readonly>
                        </div>
                        <div class="form-group col-md-2">
                            <label>Telp.</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->TelpLembaga); ?>" readonly>
                        </div>
                        <div class="form-group col-md-2">
                            <label>E-Mail</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->EmailLembaga); ?>" readonly>
                        </div>
                        <div class="form-group col-md-6">
                            <label>Alamat</label>
                            <input type="text" class="form-control bg-white" value="<?php echo e($deliveries->salesorder->customer->AlamatLembaga); ?>" readonly>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>


        <!-- end: Show Data -->
        <div class="col-lg-12">
            <div class="dt-responsive table-responsive mb-3">
                <table class="table mb-0">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th colspan="2">Produk</th>
                            <th>Jumlah</th>
                            <th>Harga Satuan</th>
                            <th>Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $deliveryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td width="60px">
                                <img class="avatar-40 rounded" src="<?php echo e($item->product->product_image ? asset('storage/products/'.$item->product_image) : asset('storage/products/default.webp')); ?>">
                            </td>
                            <td>
                                <h6><?php echo e($item->product->product_name); ?></h6>
                                <p> <?php echo e($item->product->category->name); ?></p>
                                
                            </td>
                            <td style="text-align: center"><?php echo e(number_format($item->quantity)); ?></td>
                            <td style="text-align: right">Rp <?php echo e(number_format($item->unitcost)); ?></td>
                            <td style="text-align: right">Rp <?php echo e(number_format($item->total)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="row mb-5">
                <div class="offset-lg-6 col-lg-6">
                    <div class="or-detail rounded ">
                        <div class="bg-primary pl-3 pt-2 pb-2">
                            <h4>Total</h4>
                        </div>
                        <div class="ttl-amt py-2 px-3 d-flex justify-content-between align-items-center ">
                            <h5>Total Produk</h5>
                            <h3 class="text-primary font-weight-700"><?php echo e($deliveries->total_products); ?></h3>
                            <h5>Subtotal</h5>
                            <h3 class="text-primary font-weight-700">Rp <?php echo e(number_format($deliveries->sub_total)); ?></h3>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Page end  -->
</div>

<?php echo $__env->make('components.preview-img-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/details-delivery.blade.php ENDPATH**/ ?>