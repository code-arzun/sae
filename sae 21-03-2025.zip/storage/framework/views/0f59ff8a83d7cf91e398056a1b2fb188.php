<?php $__env->startSection('container'); ?>

<h2>Data Sales</h2>
<nav aria-label="breadcrumb">
    <ol class="breadcrumb breadcrumb-default-icon">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ti ti-home-2"></i></a></li>
        <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('sales')); ?>">Data Sales</a></li>
    </ol>
</nav>

<!-- Data -->
<div class="col-lg-12">
    <ul class="nav nav-tabs mb-3" id="sales" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="all-tab" data-bs-toggle="tab" href="#all" role="tab"><h6><i class="ti ti-table me-2"></i>Semua</h6></a>
        </li>
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesrep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a class="nav-link" id="detail-tab-<?php echo e($salesrep->id); ?>" data-bs-toggle="tab" href="#detail-<?php echo e($salesrep->id); ?>" role="tab">
                    <h6><i class="ti ti-table me-2"></i><?php echo e($salesrep->name); ?></h6>
                </a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="tab-content" id="salesContent">
        <!-- All -->
        <?php echo $__env->make('marketing.sales.partials.all', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Sales -->
        
        <?php echo $__env->make('marketing.sales.partials.detail', ['salesrep' => $salesrep], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/sales/index.blade.php ENDPATH**/ ?>