<?php $__env->startSection('specificpagestyles'); ?>
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://unpkg.com/gijgo@1.9.14/js/gijgo.min.js" type="text/javascript"></script>
    <link href="https://unpkg.com/gijgo@1.9.14/css/gijgo.min.css" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <?php if(session()->has('created')): ?>
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    showCreatedAlert("<?php echo e(session('created')); ?>");
                });
            </script>
        <?php endif; ?>
        <div class="col-lg-12 d-flex flex-wrap mb-3">
            <div>
                <a href="<?php echo e(url()->previous()); ?>" class="badge bg-primary me-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Kembali"><i class="fa fa-arrow-left mb-1 mt-1"></i></a>
                <a href="<?php echo e(route('input.collection')); ?>" class="badge bg-secondary me-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Muat Ulang Halaman"><i class="fa fa-refresh mb-1 mt-1"></i></a>
            </div>
            <div>
                <h4>Input Collection</h4>
            </div>
        </div>
    </div>
    <form action="<?php echo e(route('inputCol.confirmation')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- Dropdown untuk memilih sales order -->
            <div class="form-group col-md-12 mb-3">
                <label for="order_id">Pilih Sales Order</label>
                <select class="form-control order_id bg-white text-center" name="order_id" id="order_id" onchange="calculateCollection()">
                    <option value="">Pilih Sales Order</option>
                    <?php $__currentLoopData = $salesorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($salesorder->id); ?>" <?php echo e(request('order_id') == $salesorder->id ? 'selected' : ''); ?>

                            data-due="<?php echo e($salesorder->due); ?>"
                            data-discount="<?php echo e($salesorder->discount_percent); ?>"
                            data-customer="<?php echo e($salesorder->customer->NamaCustomer); ?>">
                            <?php echo e($salesorder->invoice_no); ?> | <?php echo e($salesorder->customer->NamaLembaga); ?> - 
                            <?php echo e($salesorder->customer->NamaCustomer); ?> | Rp <?php echo e(number_format($salesorder->due)); ?> | <?php echo e($salesorder->payment_status); ?>  | <?php echo e($salesorder->customer->employee->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        <!-- Metode Pembayaran -->
            <div class="row-sm-12 d-flex mb-3">
                <!-- Total Tagihan -->
                    <div class="form-group col-md-2">
                        <label for="data-due">Total Tagihan</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-danger">Rp</span>
                            </div>
                            <input type="number" class="form-control text-center bg-white" id="data-due" name="data-due" value="<?php echo e(number_format($salesorder->due)); ?>" readonly>
                        </div>
                    </div>
                <!-- Dibayar oleh -->
                <div class="form-group col-md-2">
                    <label for="paid_by">Dibayar oleh</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <button type="button" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Dibayar oleh Customer" id="paidByCustomer"><i class="fa-solid fa-person me-0"></i></button>
                        </div>
                        <input type="text" class="form-control text-center <?php $__errorArgs = ['paid_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="paid_by" name="paid_by" value="<?php echo e(old('paid_by')); ?>" required>
                    </div>
                </div>
                <?php $__errorArgs = ['paid_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <!-- Metode Pembayaran -->
                    <div class="form-group col-md-2">
                        <label for="payment_method">Metode Pembayaran</label>
                        <div class="col-md">
                            <input type="radio" id="tunai" name="payment_method" value="Tunai" hidden>
                            <label class="btn btn-outline-secondary tunai me-2" for="tunai"> Tunai </label>
                            <input type="radio" id="transfer" name="payment_method" value="Transfer" hidden>
                            <label class="btn btn-outline-success transfer" for="transfer"> Transfer </label>
                        </div>
                    </div>
                <!-- Diterima oleh -->
                    <div class="form-group col-md-3" id="penerima" style="display: none;">
                        <label for="received_by">Diterima oleh</label>
                        <select class="form-control bg-white text-center  <?php $__errorArgs = ['received_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="received_by" id="received_by">
                            <option value="" selected disabled>Pilih Penerima</option>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <?php $__errorArgs = ['received_by'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback">
                        <?php echo e($message); ?>

                    </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                
                <!-- Bank Pengirim -->
                    <div class="form-group col-md-1" id="bankPengirim" style="display: none;">
                        <label for="bank">Bank Pengirim</label>
                        <select class="form-control bg-white text-center" name="bank" id="bank">
                            <option value="" selected disabled>Pilih Bank</option>
                            <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($bank->id); ?>"><?php echo e($bank->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                <!-- Nomor Rekening -->
                    <div class="form-group col-md-2" id="rekeningPengirim" style="display: none;">
                        <label for="no_rek">Rekening Pengirim</label>
                        <input type="text" class="form-control text-center" id="no_rek" name="no_rek" value="<?php echo e(old('no_rek')); ?>">
                    </div>

                <!-- Bank Pengirim -->
                    <div class="form-group col-md-3" id="rekeningPenerima" style="display: none;">
                        <label for="transfer_to">Rekening Penerima</label>
                        <select class="form-control bg-white text-center" name="transfer_to" id="transfer_to">
                        
                            <option value="" selected disabled>Pilih Rekening Penerima</option>
                            <?php $__currentLoopData = $rekenings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekening): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($rekening->id); ?>"><?php echo e($rekening->bank->name); ?> - <?php echo e($rekening->no_rek); ?> | <?php echo e($rekening->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
            </div>
        <!-- Nominal Pembayaran -->
            <div class="row-sm-12 d-flex flex-wrap">
                <!-- Input untuk pembayaran -->
                    <div class="form-group col-md">
                        <label for="pay">Nominal Pembayaran</label>
                        
                        <div class="input-group mb-3">
                            <div class="input-group-prepend">
                              <button class="btn btn-primary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Pilih Jumlah</button>
                              <span class="input-group-text">Rp</span>
                              <div class="dropdown-menu">
                                  <a class="dropdown-item" href="#" id="fullPay">Bayar Penuh</a>
                                  <a class="dropdown-item" href="#" id="pay75%">75%</a>
                                  <a class="dropdown-item" href="#" id="pay50%">50%</a>
                                  <a class="dropdown-item" href="#" id="pay25%">25%</a>
                              </div>
                            </div>
                            <input type="number" class="form-control text-center <?php $__errorArgs = ['pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="pay" name="pay" value="<?php echo e(old('pay', 0)); ?>" oninput="calculateCollection()" required>
                        </div>
                    </div>
                    <?php $__errorArgs = ['pay'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback">
                            <?php echo e($message); ?>

                        </div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <!-- Input untuk diskon (persen) -->
                        <div class="form-group col-md-4">
                            <label for="discount_percent">Diskon </label>
                            <div class="row d-flex">
                                <div class="input-group col-md-5 mb-3">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Diskon sesuai Sales Order" id="discount">%</button>
                                    </div>
                                    <input type="number" step="0.01"  class="form-control text-center" id="discount_percent" name="discount_percent" value="<?php echo e(old('discount_percent', 0)); ?>" oninput="calculateCollection()">
                                    <div class="input-group-append">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                                <div class="input-group col-md mb-3">
                                    <div class="input-group-prepend">
                                    <span class="input-group-text">Rp</span>
                                    </div>
                                    <input type="number" class="form-control text-center bg-white" id="discount_rp" name="discount_rp" value="<?php echo e(old('discount_rp', 0)); ?>" aria-label="Amount (to the nearest Rupiah)" readonly>
                                </div>
                            </div>
                        </div>
        
                    <!-- Input untuk PPh22 (persen) -->
                        <div class="form-group col-md-4">
                            <label for="PPh22_percent">PPh22 </label>
                            <div class="row d-flex">
                                <div class="input-group col-md-6 mb-3">
                                    <div class="input-group-prepend">
                                        <button type="button" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="PPh22" id="PPh22">0,5%</button>
                                    </div>
                                    <input type="number" step="0.01"  class="form-control text-center" id="PPh22_percent" name="PPh22_percent" value="<?php echo e(old('PPh22_percent', 0)); ?>" oninput="calculateCollection()">
                                    <div class="input-group-append">
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                                <div class="input-group col-md mb-3">
                                    <div class="input-group-prepend">
                                    <span class="input-group-text">Rp</span>
                                    </div>
                                    <input type="number" class="form-control text-center bg-white" id="PPh22_rp" name="PPh22_rp" value="<?php echo e(old('PPh22_rp', 0)); ?>" readonly>
                                </div>
                            </div>
                        </div>
            </div>
        <!-- Biaya-biaya -->
            <div class="row-sm-12 d-flex flex-wrap">
                <!-- Input untuk PPN (persen) -->
                    <div class="form-group col-md-4">
                        <label for="PPN_percent">PPN </label>
                        <div class="row d-flex">
                            <div class="input-group col-md-5 mb-3">
                                <div class="input-group-prepend">
                                    <button type="button" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="PPN" id="PPN">11%</button>
                                </div>
                                <input type="number" step="0.01"  class="form-control text-center" id="PPN_percent" name="PPN_percent" value="<?php echo e(old('PPN_percent', 0)); ?>" oninput="calculateCollection()">
                                <div class="input-group-append">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                            <div class="input-group col-md mb-3">
                                <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                                </div>
                                <input type="number" class="form-control text-center bg-white" id="PPN_rp" name="PPN_rp" value="<?php echo e(old('PPN_rp', 0)); ?>" readonly>
                            </div>
                        </div>
                    </div>
                <!-- Input untuk biaya admin -->
                    <div class="form-group col-md-4">
                        <label for="admin_fee">Biaya Admin</label>
                        <div class="input-group col-md">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                            </div>
                            <input type="number" class="form-control text-center" id="admin_fee" name="admin_fee" value="<?php echo e(old('admin_fee', 0)); ?>" oninput="calculateCollection()">
                        </div>
                    </div>
    
                <!-- Input untuk biaya lain-lain -->
                    <div class="form-group col-md-4">
                        <label for="other_fee">Biaya Lain-Lain</label>
                        <div class="input-group col-md">
                            <div class="input-group-prepend">
                                <span class="input-group-text">Rp</span>
                            </div>
                            <input type="number" class="form-control text-center" id="other_fee" name="other_fee" value="<?php echo e(old('other_fee', 0)); ?>" oninput="calculateCollection()">
                        </div>
                    </div>
            </div>
        <!-- Status & Total Akhir -->
            <div class="row-sm-12 d-flex flex-wrap">
                <!-- Status Pembayaran -->
                    <div class="form-group col-md-2" id="status">
                        <label for="payment_status">Status Pembayaran</label>
                        <div class="col">
                            <input type="radio" value="Belum Dibayar" id="belum_dibayar" name="payment_status" hidden>
                                <label class="col-md btn btn-outline-danger belum_dibayar me-2" for="belum_dibayar" id="labelBelumDibayar">Belum Dibayar</label>
                            <input type="radio" value="Belum Lunas" id="belum_lunas" name="payment_status" value="Belum Lunas" hidden>
                                <label class="col-md btn btn-outline-warning belum_lunas me-2" for="belum_lunas" id="labelBelumLunas">Belum Lunas</label>
                            <input type="radio" value="Lunas" id="lunas" name="payment_status" value="Lunas" hidden>
                                <label class="col-md btn btn-outline-success lunas" for="lunas" id="labelLunas">Lunas</label>
                        </div>
                    </div>
                <!-- Output untuk tagihan -->
                    <div class="form-group col-md">
                        <label for="due">Sisa Tagihan</label>
                        <div class="input-group col-md">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-secondary">Rp</span>
                            </div>
                            <input type="number" class="form-control text-center font-weight-bold bg-white" id="due" name="due" value="<?php echo e(old('due', 0)); ?>" readonly>
                        </div>
                    </div>
                <!-- Output untuk total akhir -->
                    <div class="form-group col-md">
                        <label for="grandtotal">Total Akhir Diterima</label>
                        <div class="input-group col-md">
                            <div class="input-group-prepend">
                                <span class="input-group-text bg-success">Rp</span>
                            </div>
                            <input type="number" class="form-control text-center font-weight-bold bg-white" id="grandtotal" name="grandtotal" value="<?php echo e(old('grandtotal', 0)); ?>" readonly>
                        </div>
                    </div>
            </div>
            <div class="row-md-12 mt-3 mb-5">
                <button type="submit" class="btn btn-success w-100"><b>Buat Collection</b></button>
            </div>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/finance/collection/input.blade.php ENDPATH**/ ?>