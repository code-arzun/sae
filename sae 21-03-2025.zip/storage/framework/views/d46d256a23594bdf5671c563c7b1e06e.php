<table class="table table-light">
    <thead class="bg-danger">
        <th>Pengiriman ke-</th>
        <th>Tgl. DO</th>
        <th width="170px">No. DO</th>
        <th>Subtotal</th>
        <th>Terpacking</th>
        <th>Dikirim</th>
        <th>Terkirim</th>
        <th>Status</th>
    </thead>
    <tbody>
        <?php $__currentLoopData = $deliveries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $delivery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($loop->iteration); ?></td>
            <td>
                <span class="" data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(Carbon\Carbon::parse($delivery->delivery_date)->translatedformat('l, d F Y')); ?>">
                    <?php echo e(Carbon\Carbon::parse($delivery->delivery_date)->translatedformat('d M Y')); ?>

                </span>
            </td>
            <td class="text-center">
                <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin', 'Admin Gudang'])): ?>
                    <div class="d-flex justify-content-between align-items-center">
                        <a class="badge <?php echo e(strpos($delivery->invoice_no, '-RO') !== false ? 'bg-primary' : (strpos($delivery->invoice_no, '-HO') !== false ? 'bg-danger' : 
                            (strpos($delivery->invoice_no, '-RS') !== false ? 'bg-success' : (strpos($delivery->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary')))); ?>" 
                            href="<?php echo e(route('do.deliveryDetails', $delivery->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Pesanan">
                            <?php echo e($delivery->invoice_no); ?>

                        </a>
                        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                            <a href="<?php echo e(route('do.invoiceDownload', $delivery->id)); ?>" class="badge bg-secondary me-2" data-bs-toggle="tooltip"
                                data-bs-placement="top" title="Cetak Dokumen DO"><i class="fa fa-print me-0" aria-hidden="true"></i> 
                            </a>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                <a class="badge <?php echo e(strpos($delivery->invoice_no, '-RO') !== false ? 'bg-primary' : (strpos($delivery->invoice_no, '-HO') !== false ? 'bg-danger' : 
                    (strpos($delivery->invoice_no, '-RS') !== false ? 'bg-success' : (strpos($delivery->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary')))); ?>" 
                    href="<?php echo e(route('do.deliveryDetails', $delivery->id)); ?>" data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail Pesanan">
                    <?php echo e($delivery->invoice_no); ?>

                </a>
                <?php endif; ?>
            </td>
            <td class="accounting subtotal"><?php echo e(number_format($delivery->sub_total)); ?></td>
            <td class="text-center"><?php echo e($delivery->packed_at ? Carbon\Carbon::parse($delivery->packed_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
            <td class="text-center"><?php echo e($delivery->sent_at ? Carbon\Carbon::parse($delivery->sent_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
            <td class="text-center"><?php echo e($delivery->delivered_at ? Carbon\Carbon::parse($delivery->delivered_at)->translatedFormat('H:i - l, d M Y') : ''); ?></td>
            <td class="text-center">
                <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin', 'Admin Gudang'])): ?>
                    <?php if($delivery->delivery_status === 'Siap dikirim'): ?>
                        <a href="#" class="badge bg-danger w-100" data-bs-toggle="modal" data-bs-target="#sent<?php echo e($delivery->id); ?>" data-id="<?php echo e($delivery->id); ?>"><?php echo e($delivery->delivery_status); ?></a>
                        <?php echo $__env->make('warehouse.delivery.partials.modal-sent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php elseif($delivery->delivery_status === 'Dalam Pengiriman'): ?>
                        <a href="#" class="badge bg-warning w-100" data-bs-toggle="modal" data-bs-target="#delivered<?php echo e($delivery->id); ?>" data-id="<?php echo e($delivery->id); ?>"><?php echo e($delivery->delivery_status); ?></a>
                        <?php echo $__env->make('warehouse.delivery.partials.modal-delivered', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?>
                        <span class="badge bg-success w-100"><?php echo e($delivery->delivery_status); ?></span>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if($delivery->delivery_status === 'Siap dikirim'): ?>
                        <span class="badge bg-danger w-100"><?php echo e($delivery->delivery_status); ?></span>
                    <?php elseif($delivery->delivery_status === 'Dalam Pengiriman'): ?>
                        <span class="badge bg-warning w-100"><?php echo e($delivery->delivery_status); ?></span>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot class="bg-secondary">
        <th class="text-start">Total Pengiriman</th>
        <th class="text-start"><span class="badge bg-success"><?php echo e(number_format($order->deliveries->count('sub_total'))); ?> kali</span></th>
        <th class="text-end">Total Subtotal</th>
        <th class="text-end"><span class="badge bg-success">Rp <?php echo e(number_format($order->deliveries->sum('sub_total'))); ?></span></th>
    </tfoot>
</table><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/partials/details.blade.php ENDPATH**/ ?>