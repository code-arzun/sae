<div id="save" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="saveTitle" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
      <div class="modal-content">
        <div class="modal-header bg-primary">
          <h5 class="modal-title text-white" id="saveTitle">Simpan Sales Order Baru</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body d-flex justify-content-between">
            <div class="d-flex flex-column align-items-center text-center">
                <label class="text-secondary mb-2">Tanggal Pemesanan</label>
                
            </div>
            <div class="d-flex flex-column align-items-center text-center">
                <label class="text-secondary mb-2">Nama Lembaga</label>
                <h4><?php echo e($customer->NamaLembaga); ?></h4>
            </div>
            <div class="d-flex flex-column align-items-center text-center">
                <label class="text-secondary mb-2">Nama Customer</label>
                <h4><?php echo e($customer->NamaCustomer); ?></h4>
            </div>
            <div class="d-flex flex-column align-items-center text-center">
                <label class="text-secondary mb-2">Sales</label>
                <h4><?php echo e(explode(' ', $customer->employee->name)[0]); ?></h4>
            </div>
        </div>
        
        <div class="modal-footer bg-gray-100">
            <span class="badge bg-danger w-100 mb-3">Pastikan data yang Anda masukkan sudah benar!</span>
            <div class="d-flex justify-content-between" data-extra-toggle="confirmation">
                <?php
                    $salesOrders = [
                        ['route' => 'store.SOReguler', 'label' => 'Reguler'],
                        ['route' => 'store.SOHet', 'label' => 'HET'],
                        ['route' => 'store.SOROnline', 'label' => 'Reguler SIPLah'],
                        ['route' => 'store.SOHOnline', 'label' => 'HET SIPLah']
                        // ['route' => 'store.SOReguler', 'label' => 'R-Offline'],
                        // ['route' => 'store.SOHet', 'label' => 'H-Offfline'],
                        // ['route' => 'store.SOROnline', 'label' => 'R-Online'],
                        // ['route' => 'store.SOHOnline', 'label' => 'H-Online']
                    ];
                ?>

                <?php $__currentLoopData = $salesOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $btnClass = Str::contains($order['label'], 'SIPLah') ? 'btn-info' : 'btn-warning';
                    ?>

                    <form action="<?php echo e(route($order['route'])); ?>" method="post" class="confirmation-form">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="customer_id" value="<?php echo e($customer->id); ?>">
                        <input type="hidden" name="discount_percent" value="<?php echo e($discount_percent); ?>">
                        <input type="hidden" name="discount_rp" value="<?php echo e($discount_rp); ?>">
                        <input type="hidden" name="grandtotal" value="<?php echo e($grandtotal); ?>">
                        <button type="submit" class="btn <?php echo e($btnClass); ?> me-3 confirm-button"><b><?php echo e($order['label']); ?></b></button>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
      </div>
    </div>
</div><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/input/save.blade.php ENDPATH**/ ?>