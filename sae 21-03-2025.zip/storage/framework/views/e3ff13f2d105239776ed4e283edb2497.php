<div class="tab-pane fade show active" id="all" role="tabpanel">
    <div class="row">
        <div class="col-md-6 col-xl-3">
            <div class="card">
                <div class="card-body">
                    <h6 class="mb-2 f-w-200 text-muted">Total Sales</h6>
                    <h4 class="mb-0">
                        <?php echo e($sales->count()); ?>

                        <span class="badge bg-light-primary border border-primary"></span>
                    </h4>
                </div>
                <div id="total-value-graph-1"></div>
            </div>
        </div>
    </div>
    <div class="row">
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesrep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-xl-3">
            <a class="nav-link" id="detail-tab-card-<?php echo e($salesrep->id); ?>" data-bs-toggle="tab" href="#detail-<?php echo e($salesrep->id); ?>" role="tab">
                <div class="card">
                    <div class="card-body">
                        <img src="<?php echo e(asset('assets/images/')); ?>" alt="" class="img-fluid">
                        <h4 class="mb-2"><?php echo e($salesrep->name); ?></h4>
                        <?php echo e($salesrep->position->name); ?>

                    </div>
                </div>
            </a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/sales/partials/all.blade.php ENDPATH**/ ?>