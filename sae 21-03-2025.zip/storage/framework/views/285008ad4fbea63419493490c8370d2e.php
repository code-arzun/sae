<nav class="pc-sidebar pc-sidebar-hide">
  <div class="navbar-wrapper">
    <div class="m-header">
      <a href="<?php echo e(route('dashboard')); ?>" class="b-brand text-primary">
        <!-- Logo -->
        <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="logo" height="50px" alt="logo">
      </a>
    </div>
    <div class="navbar-content">
      <ul class="pc-navbar">
        <li class="pc-item">
          <a href="<?php echo e(route('dashboard')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-dashboard"></i></span>
            <span class="pc-mtext">Dashboard</span>
          </a>
        </li>
        <li class="pc-item">
          <a href="<?php echo e(route('myattendance')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-calendar-plus"></i></span>
            <span class="pc-mtext">Absensi</span>
          </a>
        </li>

        <!-- Marketing -->
        <?php if(auth()->user()->can('customer')): ?>
        <li class="pc-item pc-caption">
          <label>Marketing</label>
          <i class="ti ti-dashboard"></i>
        </li>
        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
          <li class="pc-item">
            <a href="<?php echo e(route('sales')); ?>" class="pc-link">
              <span class="pc-micon"><i class="ti ti-users"></i></span>
              <span class="pc-mtext">Sales</span>
            </a>
          </li>
        <?php endif; ?>
        <?php if(auth()->user()->can('customer')): ?>
        <li class="pc-item">
          <a href="<?php echo e(route('customers.index')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-users"></i></span>
            <span class="pc-mtext">Customer</span>
          </a>
        </li>
        <?php endif; ?>
        <li class="pc-item">
          <a href="<?php echo e(route('so.index')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-color-swatch"></i></span>
            <span class="pc-mtext">Sales Order</span>
          </a>
        </li>
        <?php endif; ?>

        

        <li class="pc-item pc-caption">
          <label>Gudang</label>
          <i class="ti ti-news"></i>
        </li>
        <li class="pc-item">
          <a href="<?php echo e(route('do.index')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-lock"></i></span>
            <span class="pc-mtext">Delivery Order</span>
          </a>
        </li>
        <li class="pc-item">
          <a href="<?php echo e(route('retur.all')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-user-plus"></i></span>
            <span class="pc-mtext">Retur</span>
          </a>
        </li>
        <li class="pc-item">
          <a href="<?php echo e(route('stock.all')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-lock"></i></span>
            <span class="pc-mtext">Stok</span>
          </a>
        </li>
        <li class="pc-item">
          <a href="<?php echo e(route('products.index')); ?>" class="pc-link">
            <span class="pc-micon"><i class="ti ti-user-plus"></i></span>
            <span class="pc-mtext">Produk</span>
          </a>
        </li>
        

        
      </ul>
    </div>
  </div>
</nav><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/layout/partials/sidebar.blade.php ENDPATH**/ ?>