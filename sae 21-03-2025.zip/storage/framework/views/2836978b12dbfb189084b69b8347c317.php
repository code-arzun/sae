<!-- Pencarian & Filter -->
<form action="#" method="get">
    <div class="d-flex flex-wrap align-items-center row">
        <div class="form-group col-sm-3">
            <select name="jenjang" id="jenjang" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Jenjang" onchange="this.form.submit()">
                <option selected disabled>-- Jenjang --</option>
                <option value="" <?php if(request('jenjang') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="SD" <?php if(request('jenjang') == 'SD'): ?> selected="selected" <?php endif; ?>>SD</option>
                <option value="SMP" <?php if(request('jenjang') == 'SMP'): ?> selected="selected" <?php endif; ?>>SMP</option>
                <option value="SMA" <?php if(request('jenjang') == 'SMA'): ?> selected="selected" <?php endif; ?>>SMA</option>
            </select>
        </div>
        <div class="form-group col-sm-3">
            <select name="kelas" id="kelas" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kelas" onchange="this.form.submit()">
                <option selected disabled>-- Kelas --</option>
                <option value="" <?php if(request('kelas') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="Kelas 1" <?php if(request('kelas') == 'Kelas 1'): ?> selected="selected" <?php endif; ?>>Kelas 1</option>
                <option value="Kelas 2" <?php if(request('kelas') == 'Kelas 2'): ?> selected="selected" <?php endif; ?>>Kelas 2</option>
                <option value="Kelas 3" <?php if(request('kelas') == 'Kelas 3'): ?> selected="selected" <?php endif; ?>>Kelas 3</option>
                <option value="Kelas 4" <?php if(request('kelas') == 'Kelas 4'): ?> selected="selected" <?php endif; ?>>Kelas 4</option>
                <option value="Kelas 5" <?php if(request('kelas') == 'Kelas 5'): ?> selected="selected" <?php endif; ?>>Kelas 5</option>
                <option value="Kelas 6" <?php if(request('kelas') == 'Kelas 6'): ?> selected="selected" <?php endif; ?>>Kelas 6</option>
                <option value="Kelas 7" <?php if(request('kelas') == 'Kelas 7'): ?> selected="selected" <?php endif; ?>>Kelas 7</option>
                <option value="Kelas 8" <?php if(request('kelas') == 'Kelas 8'): ?> selected="selected" <?php endif; ?>>Kelas 8</option>
                <option value="Kelas 9" <?php if(request('kelas') == 'Kelas 9'): ?> selected="selected" <?php endif; ?>>Kelas 9</option>
                <option value="Kelas 10" <?php if(request('kelas') == 'Kelas 10'): ?> selected="selected" <?php endif; ?>>Kelas 10</option>
                <option value="Kelas 11" <?php if(request('kelas') == 'Kelas 11'): ?> selected="selected" <?php endif; ?>>Kelas 11</option>
                <option value="Kelas 12" <?php if(request('kelas') == 'Kelas 12'): ?> selected="selected" <?php endif; ?>>Kelas 12</option>
            </select>
        </div>
        <div class="form-group col-sm-3">
            <select name="category_id" id="category_id" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kategori" onchange="this.form.submit()">
                <option selected disabled>-- Kategori --</option>
                <option value="" <?php if(request('category_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->category_id); ?>" <?php echo e(request('category_id') == $category->category->id ? 'selected' : ''); ?>>
                    <?php echo e($category->category->name); ?> 
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-sm-3">
            <select name="mapel" id="mapel" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Mata Pelajaran" onchange="this.form.submit()">
                <option selected disabled>-- Mata Pelajaran --</option>
                <option value="" <?php if(request('mapel') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="Indonesia" <?php if(request('mapel') == 'Indonesia'): ?> selected="selected" <?php endif; ?>>Bahasa Indonesia</option>
                <option value="Jawa" <?php if(request('mapel') == 'Jawa'): ?> selected="selected" <?php endif; ?>>Bahasa Jawa</option>
                <option value="Inggris" <?php if(request('mapel') == 'Inggris'): ?> selected="selected" <?php endif; ?>>Bahasa Inggris</option>
                <option value="Matematika" <?php if(request('mapel') == 'Matematika'): ?> selected="selected" <?php endif; ?>>Matematika</option>
                <option value="IPAS" <?php if(request('mapel') == 'IPAS'): ?> selected="selected" <?php endif; ?>>IPAS</option>
                <option value="Pancasila" <?php if(request('mapel') == 'Pancasila'): ?> selected="selected" <?php endif; ?>>Pend. Pancasila</option>
                <option value="Islam" <?php if(request('mapel') == 'Islam'): ?> selected="selected" <?php endif; ?>>Pend. Agama Islam</option>
                <option value="PJOK" <?php if(request('mapel') == 'PJOK'): ?> selected="selected" <?php endif; ?>>PJOK</option>
                <option value="Rupa" <?php if(request('mapel') == 'Rupa'): ?> selected="selected" <?php endif; ?>>Seni Rupa</option>
                <option value="Musik" <?php if(request('mapel') == 'Musik'): ?> selected="selected" <?php endif; ?>>Seni Musik</option>
                <option value="Tari" <?php if(request('mapel') == 'Tari'): ?> selected="selected" <?php endif; ?>>Seni Tari</option>
                <option value="Teater" <?php if(request('mapel') == 'Teater'): ?> selected="selected" <?php endif; ?>>Seni Teater</option>
                <option value="PPKN" <?php if(request('mapel') == 'PPKN'): ?> selected="selected" <?php endif; ?>>PPKN</option>
            </select>
        </div>
        <div class="form-group col-sm-12">
            <input type="text" id="search" class="form-control" name="search" placeholder="Cari Produk" value="<?php echo e(request('search')); ?>" onblur="this.form.submit()">
        </div>
    </div>
</form>

<!-- Daftar Produk -->
<table class="table bg-white nowrap mt-2">
    <thead>
        <tr>
            <th>Nama Produk</th>
            <th width="150px">Harga</th>
            <th width="50px">Stok</th>
            <th width="50px">#</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
            <td>
                <h5><?php echo e($product->product_name); ?></h5>
                <span class="text-secondary"><?php echo e($product->category->name); ?></span>
            </td>
            <td class="text-end">Rp <?php echo e(number_format($product->selling_price)); ?></td>
            <td class="text-center">
                <?php if($product->product_store > 100): ?>
                    <b class="text-success"><?php echo e(number_format($product->product_store)); ?></b>
                <?php elseif($product->product_store >= 50 && $product->product_store <= 99): ?>
                    <b class="text-warning"><?php echo e(number_format($product->product_store)); ?></b>
                <?php else: ?>
                    <b class="text-danger"><?php echo e(number_format($product->product_store)); ?></b>
                <?php endif; ?>
                
            </td>
            <form action="<?php echo e(route('inputso.addCart')); ?>" method="POST">
            <td>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                    <input type="hidden" name="name" value="<?php echo e($product->product_name); ?>">
                    <input type="hidden" name="category" value="<?php echo e($product->category->name); ?>">
                    <input type="hidden" name="price" value="<?php echo e($product->selling_price); ?>">
                    <button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="right" title="Tambah">
                        <i class="ti ti-plus"></i>
                    </button>
                </td>
            </form>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="alert text-white bg-danger" role="alert">
            <div class="iq-alert-text">Data tidak ditemukan!</div>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
            <i class="ri-close-line"></i>
            </button>
        </div>
        <?php endif; ?>
    </tbody>
</table>
<?php echo e($products->links()); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/input/product.blade.php ENDPATH**/ ?>