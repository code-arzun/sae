<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between mb-3">
    <div>
        <h2><?php echo e($title); ?></h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-default-icon">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ti ti-home-2"></i></a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('customers.index')); ?>">Data Customer</a></li>
                
                <li class="breadcrumb-item active" aria-current="page">
                    <a href="<?php echo e(route('customers.show', $customer->id)); ?>"><?php echo e($customer->NamaLembaga); ?>_<?php echo e($customer->NamaCustomer); ?>

                        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                        _<?php echo e($customer->employee->name); ?>

                        <?php endif; ?>
                    </a>
                </li>
                
            </ol>
        </nav>
    </div>
    <div>
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editCustomer<?php echo e($customer->id); ?>"><i class="ti ti-edit"></i></button>
        <?php echo $__env->make('marketing.customers.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<div class="row mb-3">
    <div class="col-lg-12 mb-3">
        <h4>Sales</h4>
        <input type="text" class="form-control bg-white text-strong" value="<?php echo e($customer->employee->name); ?>" readonly>
    </div>
    
    <div class="col-lg-6">
        <h4>Data Lembaga</h4>
        <div class="card">
            <div class="card-body row">
                <div class="form-group col-md">
                    <label class="text-muted mb-1">Nama Lembaga</label>
                    
                    <h5><?php echo e($customer->NamaLembaga); ?></h5>
                </div>
                <div class="form-group col-md-2">
                    <label class="text-muted mb-1">Potensi</label> <br>
                    <span class="badge
                    <?php echo e(strpos($customer->Potensi, 'Tinggi') !== false ? 'bg-success' : 
                        (strpos($customer->Potensi, 'Sedang') !== false ? 'bg-warning' : 
                        (strpos($customer->Potensi, 'Rendah') !== false ? 'bg-danger' : 'bg-primary'))); ?>">
                    <?php echo e($customer->Potensi); ?></span>
                    
                </div>
                <div class="form-group col-md-12">
                    <label class="text-muted mb-1">Alamat</label>
                    
                    <h6><?php echo e($customer->AlamatLembaga); ?></h6>
                </div>
                <div class="form-group col-md-6">
                    <label class="text-muted mb-1">Telp.</label>
                    
                    <h6><?php echo e($customer->TelpLembaga); ?></h6>
                </div>
                <div class="form-group col-md-6">
                    <label class="text-muted mb-1">E-Mail</label>
                    
                    <h6><?php echo e($customer->EmailLembaga); ?></h6>
                </div>
                <div class="form-group col-md-12">
                    <label class="text-muted mb-1">Catatan</label>
                    
                    <h6><?php echo e($customer->CatatanLembaga); ?></h6>
                </div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <h4>Data Customer</h4>
        <div class="card">
            <div class="card-body row">
                <div class="col-md-4">
                    <div class="profile-img position-relative">
                        <img src="<?php echo e($customer->photo ? asset('storage/customers/' . $customer->photo) : asset('assets/images/user/1.png')); ?>" class="img-fluid rounded avatar-110" alt="profile-image">
                    </div>
                </div>
                <div class="form-group col-md-5">
                    <label class="text-muted mb-1">Nama Customer</label>
                    
                    <h5><?php echo e($customer->NamaCustomer); ?></h5>
                </div>
                <div class="form-group col-md">
                    <label class="text-muted mb-1">Jabatan</label> <br>
                    <span class="badge
                        <?php echo e(strpos($customer->Jabatan, 'Kepala Sekolah') !== false ? 'bg-success' : 
                                (strpos($customer->Jabatan, 'Bendahara') !== false ? 'bg-warning' : 
                                (strpos($customer->Jabatan, 'Operator') !== false ? 'bg-danger' : 'bg-secondary'))); ?>">
                            <?php echo e($customer->Jabatan); ?>

                    </span>
                </div>
                <div class="form-group col-md-12">
                    <label class="text-muted mb-1">Alamat</label>
                    
                    <h6><?php echo e($customer->AlamatCustomer); ?></h6>
                </div>
                <div class="form-group col-md-6">
                    <label class="text-muted mb-1">Telp.</label>
                    
                    <h6><?php echo e($customer->TelpCustomer); ?></h6>
                </div>
                <div class="form-group col-md-6">
                    <label class="text-muted mb-1">E-Mail</label>
                    
                    <h6><?php echo e($customer->EmailCustomer); ?></h6>
                </div>
                <div class="form-group col-md-12">
                    <label class="text-muted mb-1">Catatan</label>
                    
                    <h6><?php echo e($customer->CatatanCustomer); ?></h6>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="col-lg-12">
    <ul class="nav nav-tabs mb-1" id="transaction" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="salesorder-tab" data-bs-toggle="tab" href="#salesorder" role="tab"  aria-selected="true"><h6><i class="ti ti-table me-2"></i>Sales Order</h6></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="delivery-tab" data-bs-toggle="tab" href="#delivery" role="tab"  aria-selected="true"><h6><i class="ti ti-table me-2"></i>Delivery Order</h6></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="collection-tab" data-bs-toggle="tab" href="#collection" role="tab"  aria-selected="true"><h6><i class="ti ti-table me-2"></i>Collection</h6></a>
        </li>
    </ul>
    <div class="tab-content" id="transactionContent">
        <!-- Sales Order -->
        <?php echo $__env->make('marketing.customers.partials.salesorder', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Delivery Order -->
        <?php echo $__env->make('marketing.customers.partials.delivery', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Collection -->
        <?php echo $__env->make('marketing.customers.partials.collection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php echo $__env->make('components.preview-img-form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/customers/show.blade.php ENDPATH**/ ?>