<div class="row">
    <div class="col-lg-12">
        <div class="card car-transparent">
            <div class="card-body p-0">
                <div class="profile-image position-relative">
                    <img src="{{ asset('assets/images/page-img/profile.png') }}" class="img-fluid rounded w-100" alt="profile-image">
                </div>
            </div>
        </div>
    </div>
</div>
