<!-- Detail Pesanan -->
<table class="table nowrap">
    <thead>
        <tr class="text-center">
            <th width="50px">#</th>
            <th>Nama Produk</th>
            <th width="150px">Kategori</th>
            <th width="100px">Harga</th>
            <th width="50px">Jumlah</th>
            <th width="150px">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center">
                <a href="<?php echo e(route('inputdo.deleteCart', $item->rowId)); ?>" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="Hapus">
                    <i class="ti ti-trash"></i>
                </a>
            </td>
            <td data-bs-toggle="tooltip" data-bs-placement="top" title="Rp <?php echo e(number_format($item->price)); ?>">
                <b><?php echo e($item->name); ?></b> <br>
            </td>
            <td class="text-secondary"><?php echo e($item->category); ?></td>
            <td class="accounting price"><?php echo e(number_format($item->price)); ?></td>
            <td>
                <form action="<?php echo e(route('inputdo.updateCart', $item->rowId)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="number" class="form-control text-center" style="width:100px" name="qty" required
                            value="<?php echo e(old('qty', $item->qty)); ?>" 
                            onblur="validateQuantity(this)">
                    </div>
                </form>
            </td>
            <td class="accounting price"><?php echo e(number_format($item->subtotal)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
 <!-- Total -->
<table class="table nowrap">
    <tr>
        <th>
            <div class="d-flex justify-content-start">
                <span class="me-3">Total Item</span>
                <span class="badge bg-info"><?php echo e(number_format(count(Cart::content()))); ?></span>
            </div>
        </th>
        <th>
            <div class="d-flex justify-content-center">
                <span class="me-3">Total Barang</span>
                <span class="badge bg-warning"><?php echo e(number_format(Cart::count())); ?></span>
            </div>
        </th>
        <th>
            <div class="d-flex justify-content-end">
                <span class="me-3">Subtotal</span>
                <span class="badge bg-success">Rp <?php echo e(number_format(Cart::subtotal())); ?></span>
                <span id="subtotal" hidden><?php echo e(Cart::subtotal()); ?></span>
            </div>
        </th>
    </tr>
</table>

<form action="<?php echo e(route('inputdo.confirmation')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="row mt-3">
        
        <!-- SO -->
        <div class="form-group col-md" hidden>
            <label for="order_id">Sales Order</label>
            <select class="form-control order_id" name="order_id">
                <option selected="" disabled="">-- Pilih SO --</option>
                <?php $__currentLoopData = $salesorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($salesorder->id); ?>" <?php echo e(request('order_id') == $salesorder->id ? 'selected' : ''); ?>>
                        <?php echo e($salesorder->invoice_no); ?> | <?php echo e($salesorder->customer->NamaLembaga); ?> - 
                        <?php echo e($salesorder->customer->NamaCustomer); ?> | Rp <?php echo e($salesorder->sub_total); ?> | <?php echo e($salesorder->customer->employee->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['order_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="col-md-12 mt-3">
            <button type="submit" class="btn btn-success w-100">Buat Delivery Order</button>
        </div>
    </div>
</form><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/input/cart.blade.php ENDPATH**/ ?>