<?php $__env->startSection('container'); ?>

<div class="d-flex justify-content-between mb-3">
    <div>
        <h2><?php echo e($title); ?></h2>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb breadcrumb-default-icon">
                <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><i class="ti ti-home-2"></i></a></li>
                <li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('customers.index')); ?>">Data Customer</a></li>
            </ol>
        </nav>
    </div>
    <div>
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahCustomer">Tambah Customer Baru</button>
        <!-- Create -->
        <?php echo $__env->make('marketing.customers.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>






<!-- Filter -->
<form action="<?php echo e(route('customers.index')); ?>" method="get">
    <div class="row align-items-start">
        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
        <div class="form-group col-sm-2">
            <select name="employee_id" id="employee_id" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Sales" onchange="this.form.submit()">
                <option selected disabled>-- Pilih Sales --</option>
                <option value="" <?php if(request('employee_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->employee_id); ?>" <?php echo e(request('employee_id') == $employee->employee_id ? 'selected' : ''); ?>>
                    <?php echo e($employee->employee->name); ?> <!-- Adjust this to display employee's name or other details -->
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="form-group col-sm-1">
            <select name="jenjang" id="jenjang" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Jenjang" onchange="this.form.submit()">
                <option selected disabled>-- Jenjang --</option>
                <option value="" <?php if(request('jenjang') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="SD" <?php if(request('jenjang') == 'SD'): ?> selected="selected" <?php endif; ?>>SD</option>
                <option value="SMP" <?php if(request('jenjang') == 'SMP'): ?> selected="selected" <?php endif; ?>>SMP</option>
                <option value="SMA" <?php if(request('jenjang') == 'SMA'): ?> selected="selected" <?php endif; ?>>SMA</option>
            </select>
        </div>
        <div class="form-group col-sm-2">
            <select name="Potensi" id="Potensi" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Potensi" onchange="this.form.submit()">
                <option selected disabled>-- Potensi --</option>
                <option value="" <?php if(request('Potensi') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="Prioritas" <?php if(request('Potensi') == 'Prioritas'): ?> selected="selected" <?php endif; ?>>Prioritas</option>
                <option value="Tinggi" <?php if(request('Potensi') == 'Tinggi'): ?> selected="selected" <?php endif; ?>>Tinggi</option>
                <option value="Sedang" <?php if(request('Potensi') == 'Sedang'): ?> selected="selected" <?php endif; ?>>Sedang</option>
                <option value="Rendah" <?php if(request('Potensi') == 'Rendah'): ?> selected="selected" <?php endif; ?>>Rendah</option>
            </select>
        </div>
        <div class="form-group col-sm">
            <input type="text" id="search" class="form-control" name="search" 
                data-bs-toggle="tooltip" data-bs-placement="top" title="Ketik untuk melakukan pencarian!"
                onblur="this.form.submit()" placeholder="Ketik disini untuk melakukan pencarian!" value="<?php echo e(request('search')); ?>">
        </div>
    </div>
</form>
<!-- Data -->
<div class="dt-responsive">
    <table class="table table-responsive bg-white nowrap">
        <thead>
            
            <th>Nama Lembaga</th>
            <th>Nama Customer</th>
            <th>Jabatan</th>
            <th>Potensi</th>
            <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
            <th>Sales</th>
            <?php endif; ?>
            <th>Aksi</th>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><b data-bs-toggle="popover" title="<?php echo e($customer->NamaLembaga); ?>" data-content="<?php echo e($customer->AlamatLembaga); ?>"><?php echo e($customer->NamaLembaga); ?></b></td>
                <td>
                    <div class="d-flex align-items-center">
                        <img class="avatar-60 rounded" src="<?php echo e($customer->photo ? asset('storage/customers/'.$customer->photo) : asset('assets/images/user/1.png')); ?>">
                        <b class="ml-3"><?php echo e($customer->NamaCustomer); ?></b>
                    </div>
                </td>
                <td><?php echo e($customer->Jabatan); ?></td>
                <td>
                    <span class="badge <?php echo e(strpos($customer->Potensi, 'Tinggi') !== false ? 'bg-success' : (strpos($customer->Potensi, 'Sedang') !== false ? 'bg-warning' : 
                        (strpos($customer->Potensi, 'Rendah') !== false ? 'bg-danger' : '-'))); ?>">
                        <?php echo e($customer->Potensi); ?>

                    </span>
                </td>
                <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                <td><?php echo e($customer->employee->name); ?></td>
                <?php endif; ?>
                <td width="200px">
                    <div class="d-flex align-items-center justify-content-center">
                        <a class="badge bg-primary me-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail"
                                href="<?php echo e(route('customers.show', $customer->id)); ?>"><i class="ti ti-eye"></i>
                        </a>
                        <?php if(auth()->user()->hasAnyRole('Super Admin', 'Manajer Marketing', 'Admin')): ?>
                        <a href="#" class="badge bg-warning" data-bs-toggle="modal" data-bs-target="#editCustomer<?php echo e($customer->id); ?>"><i class="ti ti-edit"></i></a>
                        <!-- Edit -->
                        <?php echo $__env->make('marketing.customers.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <form action="<?php echo e(route('customers.destroy', $customer->id)); ?>" method="POST" class="confirmation-form">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="button" class="badge bg-danger delete-button" data-bs-toggle="tooltip" data-bs-placement="top" title="Delete"><i class="ti ti-trash"></i></button>
                        </form>
                        <?php endif; ?>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/customers/index.blade.php ENDPATH**/ ?>