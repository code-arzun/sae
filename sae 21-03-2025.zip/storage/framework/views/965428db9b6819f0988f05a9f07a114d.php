<table class="table bg-white nowrap mb-3">
    <thead>
        <tr>
            <th width="3px">No.</th>
            <th>Produk</th>
            <th width="250px">Kategori</th>
            <th width="150px">Jumlah</th>
            
            
            
            <th width="150px">Harga Satuan</th>
            <th width="200px">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $deliveryDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><b><?php echo e($item->product->product_name); ?></b></td>
            <td><?php echo e($item->product->category->name); ?></td>
            <td class="text-center"><b class="me-1"><?php echo e(number_format($item->quantity)); ?></b><?php echo e($item->product->category->productunit->name); ?></td>
            
            
            
            
            <td class="text-end">Rp <?php echo e(number_format($item->unitcost)); ?></td>
            <td class="text-end">Rp <?php echo e(number_format($item->total)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<div class="offset-6">
    <table class="table text-end">
            <tr>
                <th class="text-start">Jumlah Item</th>
                <td class="text-start"><span class="badge bg-secondary"><?php echo e(number_format($deliveryDetails->count('product'))); ?></span></td>
                <th class="text-start">Total Produk</th>
                <td class="text-start"><span class="badge bg-secondary me-2"><?php echo e(number_format($delivery->total_products)); ?></span><?php echo e($item->product->category->productunit->name); ?></td>
                <th>Subtotal</th>
                <td><span class="badge bg-success">Rp <?php echo e(number_format($delivery->sub_total)); ?></td>
            </tr>
        </tbody>
    </table>
</div><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/details/table.blade.php ENDPATH**/ ?>