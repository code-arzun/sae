<?php if(session()->has('success')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            showSuccessAlert("<?php echo e(session('success')); ?>");
        });
    </script>
<?php elseif(session()->has('created')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            showCreatedAlert("<?php echo e(session('created')); ?>");
        });
    </script>
<?php elseif(session()->has('added')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            showAddedAlert("<?php echo e(session('added')); ?>");
        });
    </script>
<?php elseif(session()->has('danger')): ?>
    <script>
        document.addEventListener("DOMContentLoaded", function() {
            showDangerAlert("<?php echo e(session('danger')); ?>");
        });
    </script>
<?php endif; ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/layout/partials/session.blade.php ENDPATH**/ ?>