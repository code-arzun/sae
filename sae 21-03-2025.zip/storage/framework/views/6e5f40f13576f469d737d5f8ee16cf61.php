<!-- Download button -->
<a href="<?php echo e(route('so.invoiceDownload', $order->id)); ?>"
    class="btn btn-primary mb-3" data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak Dokumen SO">
    <i class="fa fa-print me-2" aria-hidden="true"></i> Dokumen SO
</a>

<!-- Detail Table -->
<table class="table bg-white nowrap mb-3">
    <thead>
        <tr>
            <th width="3px">No.</th>
            <th>Produk</th>
            <th width="250px">Kategori</th>
            <th width="150px">Jumlah</th>
            
            
            
            <th width="150px">Harga Satuan</th>
            <th width="200px">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td><b><?php echo e($item->product->product_name); ?></b></td>
            <td><?php echo e($item->product->category->name); ?></td>
            <td class="text-center"><b class="me-1"><?php echo e(number_format($item->quantity)); ?></b><?php echo e($item->product->category->productunit->name); ?></td>
            
            
            
            
            <td class="text-end">Rp <?php echo e(number_format($item->unitcost)); ?></td>
            <td class="text-end">Rp <?php echo e(number_format($item->total)); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    
</table>

<div class="offset-6">
    <table class="table text-end">
            <tr>
                <th class="text-start">Jumlah Item</th>
                <td class="text-start"><span class="badge bg-secondary"><?php echo e(number_format($orderDetails->count('order_id'))); ?></span></td>
                <th class="text-start">Total Produk</th>
                <td class="text-start"><span class="badge bg-secondary me-2"><?php echo e(number_format($order->total_products)); ?></span><?php echo e($item->product->category->productunit->name); ?></td>
                <th>Subtotal</th>
                <td><span class="badge bg-success">Rp <?php echo e(number_format($order->sub_total)); ?></td>
            </tr>
            <tr>
                <th colspan="4">Diskon</th>
                <td><span class="badge bg-warning"><?php echo e(number_format($order->discount_percent, 2)); ?>%</span></td>
                <td><span class="badge bg-danger">Rp <?php echo e(number_format($order->discount_rp)); ?></span></td>
            </tr>
            <tr>
                <th colspan="5">Grand Total</th>
                <td><span class="badge bg-primary">Rp <?php echo e(number_format($order->grandtotal)); ?></td>
            </tr>
        </tbody>
    </table>
</div><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/details/so.blade.php ENDPATH**/ ?>