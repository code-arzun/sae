<?php $__env->startSection('container'); ?>

<div class="container-fluid">
    <div class="d-flex justify-content-between mb-3">
        <div>
            <a href="<?php echo e(url()->previous()); ?>" class="badge bg-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Kembali">
                <i class="fa fa-arrow-left mb-0"></i>
            </a>
        </div>
        <div>
            <a href="<?php echo e(route('myattendance')); ?>" class="badge bg-warning" data-bs-toggle="tooltip" data-bs-placement="top" title="Data Kehadiran Saya">
                <i class="fa fa-table mb-0"></i>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                
                <div class="card-body">
                    
                    <!-- Form Kehadiran -->
                    <?php if(!isset($attendance) || $attendance->status == null): ?>
                        <form id="attendanceForm" action="<?php echo e(route('attendance.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="row d-flex flex-wrap align-items-top">
                                <!-- Pilih Status Kehadiran -->
                                <div class="form-group col-md-3">
                                    <label data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Status Kehadiran</label><br>
                                    <div class="col">
                                        <input type="radio" id="tidak_hadir" name="status" value="Tidak Hadir" hidden>
                                        <label class="btn btn-outline-danger tidak_hadir me-2" for="tidak_hadir"> Tidak Hadir </label>
                                        <input type="radio" id="hadir" name="status" value="Hadir" hidden>
                                        <label class="btn btn-outline-primary hadir" for="hadir"> Hadir </label>
                                    </div>
                                    <!-- 
                                        <div class="form-group row-md-1">
                                            <div class="input-group-text" id="status">
                                                <div class="custom-radio">
                                                    <input type="radio" id="hadir" name="status" class="custom-control-input position-relative" style="height: 20px" value="Hadir">
                                                    <label class="custom-control-label" for="hadir"> Hadir </label>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group row-md-1">
                                            <div class="input-group-text" id="status">
                                                <div class="custom-radio">
                                                    <input type="radio" id="tidak_hadir" name="status" class="custom-control-input position-relative" style="height: 20px" value="Tidak Hadir">
                                                    <label class="custom-control-label" for="tidak_hadir"> Tidak Hadir </label>
                                                </div>
                                            </div>
                                        </div>
                                    -->
                                </div>
                                <!-- Timepicker untuk 'Hadir' -->
                                <div class="form-group col-md-2" id="timepickerDiv" style="display: none;">
                                    <label for="datang" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Jam Datang</label>
                                    <input id="datangTime" type="time" class="form-control <?php $__errorArgs = ['datang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="datang" value="<?php echo e(old('datang')); ?>" />
                                    <?php $__errorArgs = ['datang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Alasan untuk 'Tidak Hadir' -->
                                <div class="form-group col-md" id="keteranganDiv" style="display: none;">
                                    <label for="keterangan" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Keterangan</label>
                                    <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="keterangan" name="keterangan" rows="10" value="<?php echo e(old('keterangan')); ?>"></textarea>
                                    <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success mt-1">Simpan</button>
                        </form>
                    <?php else: ?>
                    <!-- Tampilkan Data Kehadiran yang Sudah Diisi -->
                        <div class="row align-items-start">
                            <div class="form-group col-md-2">
                                <label>Hari</label>
                                <input type="text" class="form-control text-center bg-white" value="<?php echo e(Carbon\Carbon::parse($attendance->created_at)->translatedFormat('l')); ?>" readonly>
                            </div>
                            <div class="form-group col-md-3">
                                <label>Tanggal</label>
                                <input type="text" class="form-control text-center bg-white" value="<?php echo e(Carbon\Carbon::parse($attendance->created_at)->translatedFormat('d F Y')); ?>" readonly>
                            </div>
                            <?php if($attendance->status == 'Hadir'): ?>
                            <div class="form-group col-md-3 text-center">
                                <label>Status Kehadiran</label> <br>
                                <span class="badge bg-success"><?php echo e($attendance->status); ?></span>
                            </div>
                            <div class="form-group col-md-2">
                                <label>Jam Datang</label>
                                <input type="text" class="form-control text-center bg-white" value="<?php echo e(Carbon\Carbon::parse($attendance->datang)->translatedFormat('H:i')); ?>" readonly>
                            </div>
                                <?php if($attendance->pulang !== null): ?>
                                    <div class="form-group col-md-2">
                                        <label>Jam Pulang</label>
                                        <input type="text" class="form-control text-center bg-white" value="<?php echo e(Carbon\Carbon::parse($attendance->pulang)->translatedFormat('H:i')); ?>" readonly>
                                    </div>
                                    <div class="form-group col-md">
                                        <label>Deskripsi pekerjaan hari ini</label>
                                        <textarea class="form-control bg-white" id="work_journal" name="work_journal" rows="20" readonly><?php echo e(old('work_journal', $attendance->work_journal)); ?></textarea>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                            <div class="form-group col-md-4">
                                <label>Status Kehadiran</label> <br>
                                <span class="badge bg-danger"><?php echo e($attendance->status); ?></span>
                            </div>
                            <div class="form-group col-md-12">
                                <label>Keterangan</label>
                                <textarea class="form-control bg-white" id="work_journal" name="work_journal" rows="20" readonly><?php echo e($attendance->keterangan); ?></textarea>
                            </div>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                    <!-- Form Pulang (muncul setelah status Hadir dan absensi disubmit) -->
                    <?php if(isset($attendance) && $attendance->status == 'Hadir' && !$attendance->pulang): ?>
                        <form id="checkoutForm" action="<?php echo e(route('attendance.update', ['attendance' => $attendance->id])); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <!-- Input Pulang -->
                            <div class="row">
                                <div class="form-group col-md-2" id="timepickerDiv">
                                    <label for="pulang" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Jam Pulang</label>
                                    <input id="pulang" type="time" class="form-control <?php $__errorArgs = ['pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pulang" value="<?php echo e(old('pulang')); ?>" required>
                                    <?php $__errorArgs = ['pulang'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        <?php echo e($message); ?>

                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <!-- Jurnal Harian Kerja -->
                                <div class="form-group col-md" id="work_journal">
                                    <label for="work_journal" data-bs-toggle="tooltip" data-bs-placement="top" title="Wajib diisi!"><span class="text-danger">*</span>Worksheet Harian</label>
                                    <textarea class="form-control <?php $__errorArgs = ['work_journal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="work_journal" name="work_journal" rows="20" value="<?php echo e(old('work_journal')); ?>" required></textarea>
                                    <?php $__errorArgs = ['work_journal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback">
                                        Worksheet harian belum diisi!
                                    </div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-success mt-1">Simpan</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const hadirRadio = document.getElementById('hadir');
        const tidakHadirRadio = document.getElementById('tidak_hadir');
        const timepickerDiv = document.getElementById('timepickerDiv');
        const keteranganDiv = document.getElementById('keteranganDiv');

        hadirRadio.addEventListener('change', function () {
            if (this.checked) {
                timepickerDiv.style.display = 'block';
                document.getElementById('datangTime').setAttribute('required', 'required');  // Tetap required saat hadir
                keteranganDiv.style.display = 'none';
                document.getElementById('keterangan').removeAttribute('required');  // Tidak required saat hadir
            }
        });

        tidakHadirRadio.addEventListener('change', function () {
            if (this.checked) {
                timepickerDiv.style.display = 'none';
                document.getElementById('datangTime').removeAttribute('required');  // Hapus required saat tidak hadir
                keteranganDiv.style.display = 'block';
                document.getElementById('keterangan').setAttribute('required', 'required');  // Set required saat tidak hadir
            }
        });

        // Handle attendance form submission
        const attendanceForm = document.getElementById('attendanceForm');
        const checkoutForm = document.getElementById('checkoutForm');

        attendanceForm?.addEventListener('submit', function (event) {
            event.preventDefault();
            const formData = new FormData(attendanceForm);

            fetch('<?php echo e(route('attendance.store')); ?>', {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
                }
            }).then(response => response.json())
              .then(data => {
                  if (data.success) {
                      attendanceForm.style.display = 'none';  // Hide attendance form after submission
                      location.reload();  // Reload to show readonly data and pulang form
                  }
              });
        });

        // Cek apakah attendance ada sebelum men-define updateUrl
        <?php if($attendance): ?>
        const updateUrl = '<?php echo e(route('attendance.update', ['attendance' => $attendance->id])); ?>';
        <?php else: ?>
        const updateUrl = '';  // Kosongkan jika tidak ada $attendance
        <?php endif; ?>

        // Handle checkout form submission
        if (updateUrl !== '') {  // Hanya jika ada updateUrl
            checkoutForm?.addEventListener('submit', function (event) {
                event.preventDefault();

                const formData = new FormData(this);

                fetch(updateUrl, {
                    method: 'POST',  // POST dengan method override PUT
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value,
                        'X-HTTP-Method-Override': 'PUT'  // Override method ke PUT
                    }
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert(data.message);
                        location.reload();
                    }
                });
            });
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/attendance/create.blade.php ENDPATH**/ ?>