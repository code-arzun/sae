<?php $__env->startSection('container'); ?>
<div class="container-fluid">

    <div class="d-flex justify-content-between mb-3">
        <div>
            <h2><?php echo e($title); ?></h2>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb breadcrumb-default-icon">
                    <?php echo $__env->make('warehouse.delivery.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </ol>
            </nav>
        </div>
        <div>
            <a href="<?php echo e(route('input.do')); ?>" class="btn btn-primary">Buat DO</a>
            <?php if(auth()->user()->hasAnyRole('Super Admin', 'Admin', 'Admin Gudang', 'Manajer Marketing')): ?>
            <a href="<?php echo e(route('do.exportData')); ?>" class="btn btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Download Excel">
                <i class="fa fa-file-excel me-2"></i>
                Download Excel
            </a>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Row & Pencarian -->
    <div class="col-lg-12">
        <form action="#" method="get">
            <div class="row align-items-start">
                <div class="form-group col-sm-2">
                    <select class="form-control" name="delivery_status"
                        data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Status Pengiriman" onchange="this.form.submit()">
                        <option selected disabled>-- Status Pengiriman --</option>
                        <option value="" <?php if(request('delivery_status') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <?php $__currentLoopData = $deliveryStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($status); ?>" <?php echo e(request('delivery_status') == $status ? 'selected' : ''); ?>>
                                <?php echo e($status); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                <div class="form-group col-sm-2">
                    <select name="employee_id" id="employee_id" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Sales" onchange="this.form.submit()">
                        <option selected disabled>-- Pilih Sales --</option>
                        <option value="" <?php if(request('employee_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($employee->employee_id); ?>" <?php echo e(request('employee_id') == $employee->employee_id ? 'selected' : ''); ?>>
                            <?php echo e($employee->employee->name); ?> <!-- Adjust this to display employee's name or other details -->
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="form-group col-sm-1">
                    <select name="delivery_invoice_no" id="delivery_invoice_no" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan jenis SO" onchange="this.form.submit()">
                        <option selected disabled>-- Pilih Kode DO --</option>
                        <option value="" <?php if(request('delivery_invoice_no') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <option value="RO" <?php if(request('invoice_no') == 'RO'): ?> selected="selected" <?php endif; ?>>DO Reguler</option>
                        <option value="HO" <?php if(request('invoice_no') == 'HO'): ?> selected="selected" <?php endif; ?>>DO HET</option>
                        <option value="RS" <?php if(request('invoice_no') == 'RS'): ?> selected="selected" <?php endif; ?>>DO Reguler Online</option>
                        <option value="HS" <?php if(request('invoice_no') == 'HS'): ?> selected="selected" <?php endif; ?>>DO HET Online</option>
                    </select>
                </div>
                <div class="form-group col-sm-1">
                    <select name="order_invoice_no" id="order_invoice_no" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan jenis SO" onchange="this.form.submit()">
                        <option selected disabled>-- Pilih Kode SO --</option>
                        <option value="" <?php if(request('order_invoice_no') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <option value="RO" <?php if(request('invoice_no') == 'RO'): ?> selected="selected" <?php endif; ?>>SO Reguler</option>
                        <option value="HO" <?php if(request('invoice_no') == 'HO'): ?> selected="selected" <?php endif; ?>>SO HET</option>
                        <option value="RS" <?php if(request('invoice_no') == 'RS'): ?> selected="selected" <?php endif; ?>>SO Reguler Online</option>
                        <option value="HS" <?php if(request('invoice_no') == 'HS'): ?> selected="selected" <?php endif; ?>>SO HET Online</option>
                    </select>
                </div>
                <div class="form-group col-sm">
                    <input type="text" id="search" class="form-control" name="search" 
                        data-bs-toggle="tooltip" data-bs-placement="top" title="Ketik untuk melakukan pencarian!"
                        onkeyup="this.form.submit()" placeholder="Ketik disini untuk melakukan pencarian!" value="<?php echo e(request('search')); ?>">
                </div>
            </div>
        </form>
    </div>
    
    <ul class="nav nav-tabs mb-3" id="delivery" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="all-tab" data-bs-toggle="tab" href="#all" role="tab"><h5><i class="ti ti-table me-2"></i>Data</h5></a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="datarecap-tab" data-bs-toggle="tab" href="#datarecap" role="tab"><h5><i class="ti ti-table me-2"></i>Rekap Data</h5></a>
        </li>
    </ul>
    <div class="tab-content" id="deliveryContent">
        <!-- All Data -->
        <div class="tab-pane fade show active" id="all" role="tabpanel">
            <?php echo $__env->make('warehouse.delivery.data.table', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <!-- Data Recap -->
        <div class="tab-pane fade" id="datarecap" role="tabpanel">
            <?php echo $__env->make('warehouse.delivery.data.recap', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/index.blade.php ENDPATH**/ ?>