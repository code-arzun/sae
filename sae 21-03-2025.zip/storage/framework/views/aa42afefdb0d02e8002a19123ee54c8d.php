<th class="text-center"><?php echo e($loop->iteration); ?></th>
<td>
    <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(Carbon\Carbon::parse($order->order_date)->translatedformat('l, d F Y')); ?>">
        <?php echo e(Carbon\Carbon::parse($order->order_date)->translatedformat('d M Y')); ?>

    </span>
</td>
<td>
    <div class="d-flex justify-content-between align-items-center">
        <a class="badge me-2
            <?php echo e(// $order->order_status === 'Menunggu persetujuan' ? 'bg-purple' : 
                (strpos($order->invoice_no, '-RO') !== false ? 'bg-primary' : 
                (strpos($order->invoice_no, '-HO') !== false ? 'bg-danger' : 
                (strpos($order->invoice_no, '-RS') !== false ? 'bg-success' : 
                (strpos($order->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary'))))); ?>"  
                href="<?php echo e(route('so.orderDetails', $order->id)); ?>" 
                data-bs-toggle="tooltip" 
                data-bs-placement="top" 
                title="Lihat Detail Pesanan">
                <?php echo e($order->invoice_no); ?>

        </a>
        <a href="<?php echo e(route('so.invoiceDownload', $order->id)); ?>"
            class="badge bg-info"  data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak dokumen SO">
            <i class="fas fa-print" aria-hidden="true"></i> 
        </a>
    </div>
</td>
<td>
    <h6 class="mb-0"><?php echo e($order->customer->NamaLembaga); ?></h6>
    <span class="text-secondary"><?php echo e($order->customer->NamaCustomer); ?></span>
</td>
<?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
<th data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($order->customer->employee->name); ?>"><?php echo e(explode(' ', $order->customer->employee->name)[0]); ?></th>
<?php endif; ?>
<td class="accounting subtotal"><?php echo e(number_format($order->sub_total)); ?></td>
<td class="accounting discountPercent"><?php echo e(number_format($order->discount_percent, 2)); ?></td>
<td class="accounting discountRp"><?php echo e(number_format($order->discount_rp)); ?></td>
<td class="accounting grandtotal"><?php echo e(number_format($order->grandtotal)); ?></td><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/layout/table/so-data.blade.php ENDPATH**/ ?>