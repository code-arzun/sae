<?php echo $__env->make('layout.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('so.index')); ?>">Sales Order</a></li>
<?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/partials/breadcrumb.blade.php ENDPATH**/ ?>