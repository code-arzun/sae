<?php echo $__env->make('layout.partials.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<li class="breadcrumb-item active" aria-current="page"><a href="<?php echo e(route('do.index')); ?>">Delivery Order</a></li>
<?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/partials/breadcrumb.blade.php ENDPATH**/ ?>