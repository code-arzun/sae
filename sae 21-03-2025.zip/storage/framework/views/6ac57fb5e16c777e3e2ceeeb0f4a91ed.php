<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <?php if(session()->has('success')): ?>
                <div class="alert text-white bg-success" role="alert">
                    <div class="iq-alert-text"><?php echo e(session('success')); ?></div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="ri-close-line"></i>
                    </button>
                </div>
            <?php endif; ?>
            <div class="col d-flex flex-wrap align-items-top justify-content-between mb-3">
                <div class="row">
                    <a href="<?php echo e(url()->previous()); ?>" class="badge bg-primary me-1" data-bs-toggle="tooltip" data-bs-placement="top" title="Kembali"><i class="fa fa-arrow-left"></i></a>
                    <a href="<?php echo e(route('product.stock')); ?>" class="badge bg-secondary" data-bs-toggle="tooltip" data-bs-placement="top" title="Muat Ulang Halaman"><i class="fa fa-refresh"></i></a>
                </div>
                <div class="row d-flex flex-wrap align-items-center justify-content-between">
                    <div class="mr-3">
                        <h4>Stok Produk</h4>
                    </div>
                    <?php if(auth()->user()->hasAnyRole('Super Admin', 'Admin', 'Admin Gudang')): ?>
                    
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Row & Pencarian -->
        <div class="col-lg-12 mb-3">
            <form action="<?php echo e(route('product.stock')); ?>" method="get">
                <div class="row align-items-center">
                    <div class="form-group col-sm-1">
                        <a href="<?php echo e(route('products.exportData')); ?>" class="btn bg-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Download Excel"><i class="fa fa-file-excel"></i></a>
                    </div>
                </div>
                <div class="row align-items-center">
                    <div class="form-group col-sm-1">
                        <select name="jenjang" id="jenjang" class="form-control"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Jenjang" onchange="this.form.submit()">
                            <option selected disabled>-- Jenjang --</option>
                            <option value="" <?php if(request('jenjang') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                            <option value="SD" <?php if(request('jenjang') == 'SD'): ?> selected="selected" <?php endif; ?>>SD</option>
                            <option value="SMP" <?php if(request('jenjang') == 'SMP'): ?> selected="selected" <?php endif; ?>>SMP</option>
                            <option value="SMA" <?php if(request('jenjang') == 'SMA'): ?> selected="selected" <?php endif; ?>>SMA</option>
                        </select>
                    </div>
                    <div class="form-group col-sm-1">
                        <select name="kelas" id="kelas" class="form-control"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kelas" onchange="this.form.submit()">
                            <option selected disabled>-- Kelas --</option>
                            <option value="" <?php if(request('kelas') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                            <option value="Kelas 1" <?php if(request('kelas') == 'Kelas 1'): ?> selected="selected" <?php endif; ?>>Kelas 1</option>
                            <option value="Kelas 2" <?php if(request('kelas') == 'Kelas 2'): ?> selected="selected" <?php endif; ?>>Kelas 2</option>
                            <option value="Kelas 3" <?php if(request('kelas') == 'Kelas 3'): ?> selected="selected" <?php endif; ?>>Kelas 3</option>
                            <option value="Kelas 4" <?php if(request('kelas') == 'Kelas 4'): ?> selected="selected" <?php endif; ?>>Kelas 4</option>
                            <option value="Kelas 5" <?php if(request('kelas') == 'Kelas 5'): ?> selected="selected" <?php endif; ?>>Kelas 5</option>
                            <option value="Kelas 6" <?php if(request('kelas') == 'Kelas 6'): ?> selected="selected" <?php endif; ?>>Kelas 6</option>
                            <option value="Kelas 7" <?php if(request('kelas') == 'Kelas 7'): ?> selected="selected" <?php endif; ?>>Kelas 7</option>
                            <option value="Kelas 8" <?php if(request('kelas') == 'Kelas 8'): ?> selected="selected" <?php endif; ?>>Kelas 8</option>
                            <option value="Kelas 9" <?php if(request('kelas') == 'Kelas 9'): ?> selected="selected" <?php endif; ?>>Kelas 9</option>
                            <option value="Kelas 10" <?php if(request('kelas') == 'Kelas 10'): ?> selected="selected" <?php endif; ?>>Kelas 10</option>
                            <option value="Kelas 11" <?php if(request('kelas') == 'Kelas 11'): ?> selected="selected" <?php endif; ?>>Kelas 11</option>
                            <option value="Kelas 12" <?php if(request('kelas') == 'Kelas 12'): ?> selected="selected" <?php endif; ?>>Kelas 12</option>
                        </select>
                    </div>
                    <div class="form-group col-sm-2">
                        <select name="category_id" id="category_id" class="form-control"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kategori" onchange="this.form.submit()">
                            <option selected disabled>-- Kategori --</option>
                            <option value="" <?php if(request('category_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->category_id); ?>" <?php echo e(request('category_id') == $category->category->id ? 'selected' : ''); ?>>
                                <?php echo e($category->category->name); ?> 
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group col-sm-2">
                        <select name="mapel" id="mapel" class="form-control"
                                data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Mata Pelajaran" onchange="this.form.submit()">
                            <option selected disabled>-- Mata Pelajaran --</option>
                            <option value="" <?php if(request('mapel') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                            <option value="Indonesia" <?php if(request('mapel') == 'Indonesia'): ?> selected="selected" <?php endif; ?>>Bahasa Indonesia</option>
                            <option value="Jawa" <?php if(request('mapel') == 'Jawa'): ?> selected="selected" <?php endif; ?>>Bahasa Jawa</option>
                            <option value="Inggris" <?php if(request('mapel') == 'Inggris'): ?> selected="selected" <?php endif; ?>>Bahasa Inggris</option>
                            <option value="Matematika" <?php if(request('mapel') == 'Matematika'): ?> selected="selected" <?php endif; ?>>Matematika</option>
                            <option value="IPAS" <?php if(request('mapel') == 'IPAS'): ?> selected="selected" <?php endif; ?>>IPAS</option>
                            <option value="Pancasila" <?php if(request('mapel') == 'Pancasila'): ?> selected="selected" <?php endif; ?>>Pend. Pancasila</option>
                            <option value="Islam" <?php if(request('mapel') == 'Islam'): ?> selected="selected" <?php endif; ?>>Pend. Agama Islam</option>
                            <option value="PJOK" <?php if(request('mapel') == 'PJOK'): ?> selected="selected" <?php endif; ?>>PJOK</option>
                            <option value="Rupa" <?php if(request('mapel') == 'Rupa'): ?> selected="selected" <?php endif; ?>>Seni Rupa</option>
                            <option value="Musik" <?php if(request('mapel') == 'Musik'): ?> selected="selected" <?php endif; ?>>Seni Musik</option>
                            <option value="Tari" <?php if(request('mapel') == 'Tari'): ?> selected="selected" <?php endif; ?>>Seni Tari</option>
                            <option value="Teater" <?php if(request('mapel') == 'Teater'): ?> selected="selected" <?php endif; ?>>Seni Teater</option>
                            <option value="PPKN" <?php if(request('mapel') == 'PPKN'): ?> selected="selected" <?php endif; ?>>PPKN</option>
                        </select>
                    </div>
                    <div class="form-group col-sm">
                        <input type="text" id="search" class="form-control" name="search" placeholder="Cari Produk" value="<?php echo e(request('search')); ?>" onblur="this.form.submit()">
                    </div>
                </div>
            </form>
        </div>

        <div class="col-lg-12">
            <div class="dt-responsive table-responsive mb-3">
                <table class="table mb-0">
                    <thead class="bg-white text-uppercase text-center">
                        <tr>
                            <th>No.</th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('product_name', 'Nama Produk'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('category.name', 'Kategori'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('selling_price', 'Harga'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('product_store', 'Stok Tersedia'));?></th>
                            <?php if(auth()->user()->hasAnyRole('Super Admin', 'Admin', 'Admin Gudang')): ?>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang TERKIRIM"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('SO Diajukan'));?></th>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang TERKIRIM"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('SO Disetujui'));?></th>
                            <th>Stok Dibutuhkan</th>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang TERKIRIM"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('DO Terpacking'));?></th>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang TERKIRIM"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('DO Dalam Pengiriman'));?></th>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang TERKIRIM"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('DO Terkirim'));?></th>
                            <th data-bs-toggle="tooltip" data-bs-placement="top" title="Rekap dari Total Produk yang DIPESAN, TERKIRIM, dan TELAH DIBAYAR LUNAS"><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('Rekap Selesai'));?></th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e((($products->currentPage() * 10) - 10) + $loop->iteration); ?></td>
                            <td>
                                <img class="avatar-60 rounded me-3" src="<?php echo e($product->product_image ? asset('storage/products/'.$product->product_image) : asset('assets/images/product/default.webp')); ?>">
                                <b><?php echo e($product->product_name); ?></b>
                            </td>
                            <td><?php echo e($product->category->name); ?></td>
                            <td>Rp <?php echo e(number_format($product->selling_price)); ?></td>
                            <td class="text-center">
                                <?php if($product->product_store >= 100): ?>
                                    <span class="badge bg-success"><?php echo e($product->product_store); ?></span>
                                <?php elseif($product->product_store >= 50 && $product->product_store <= 99): ?>
                                    <span class="badge bg-warning"><?php echo e($product->product_store); ?></span>
                                <?php else: ?>
                                    <span class="badge bg-danger"><?php echo e($product->product_store); ?></span>
                                <?php endif; ?>
                                <span class="ml-1"><?php echo e($product->category->productunit->name); ?></span>
                            </td>
                            <?php if(auth()->user()->hasAnyRole('Super Admin', 'Admin', 'Admin Gudang')): ?>
                            <!-- SO Diajukan -->
                            <td class="text-center">
                                <?php if($product->rekap_SOdiajukan > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_SOdiajukan); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_SOdiajukan); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- SO disetujui -->
                            <td class="text-center">
                                <?php if($product->rekap_SOdisetujui - $product->rekap_DOterpacking - $product->rekap_DOpengiriman - $product->rekap_DOterkirim > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_SOdisetujui - $product->rekap_DOterpacking - $product->rekap_DOpengiriman - $product->rekap_DOterkirim); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_SOdisetujui - $product->rekap_DOterpacking - $product->rekap_DOpengiriman - $product->rekap_DOterkirim); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- Stok dibutuhkan -->
                            <td class="text-center">
                                <?php if($product->rekap_SOdisetujui-$product->product_store > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_SOdisetujui-$product->product_store); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_SOdisetujui-$product->product_store); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- DO terpacking -->
                            <td class="text-center">
                                <?php if($product->rekap_DOterpacking > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_DOterpacking); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_DOterpacking); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- DO dalam pengiriman -->
                            <td class="text-center">
                                <?php if($product->rekap_DOpengiriman > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_DOpengiriman); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_DOpengiriman); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- DO terkirim -->
                            <td class="text-center">
                                <?php if($product->rekap_DOterkirim > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_DOterkirim); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_DOterkirim); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <!-- Rekap total produk selesai (lunas & terkirim) -->
                            <td class="text-center">
                                <?php if($product->rekap_selesai > 0): ?>
                                    <span class="badge bg-danger"><?php echo e($product->rekap_selesai); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php else: ?>
                                    <span class="badge bg-success"><?php echo e($product->rekap_selesai); ?></span><?php echo e($product->category->productunit->name); ?>

                                <?php endif; ?>
                            </td>
                            <?php endif; ?>
                        </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="alert text-white bg-danger" role="alert">
                            <div class="iq-alert-text">Data not Found.</div>
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <i class="ri-close-line"></i>
                            </button>
                        </div>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($products->links()); ?>

        </div>
    </div>
    <!-- Page end  -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/stock/index.blade.php ENDPATH**/ ?>