<table class="table mb-0">
    <thead class="badge-white text-uppercase">
        <tr>
            <th>Jumlah Transaksi</th>
            <th>Terpacking</th>
            <th>Dalam Pengiriman</th>
            <th>Terkirim</th>
            <th>Total Subtotal (Bruto)</th>
        </tr>
    </thead>
    <tbody class="text-center">
        <tr>
            <td><?php echo e($deliveries->count('sub_total')); ?></td>
            <td>
                <span class="btn badge-info text-white">
                    <?php echo e($deliveries->whereNotNull('packed_at')->whereNull('sent_at')->whereNull('delivered_at')->count()); ?>

                </span>
            </td>
            <td>
                <span class="btn badge-warning text-white">
                    <?php echo e($deliveries->whereNotNull('sent_at')->whereNull('delivered_at')->count()); ?>

                </span>
            </td>
            <td>
                <span class="btn badge-success text-white">
                    <?php echo e($deliveries->whereNotNull('delivered_at')->count()); ?>

                </span>
            </td>
            <td>
                <span class="btn badge-warning text-white">
                   Rp <?php echo e(number_format($deliveries->sum('sub_total'))); ?>

                </span>
            </td>
        </tr>
    </tbody>
</table><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/data/recap.blade.php ENDPATH**/ ?>