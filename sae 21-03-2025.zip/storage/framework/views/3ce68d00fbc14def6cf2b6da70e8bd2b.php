<?php $__env->startSection('container'); ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <?php if(session()->has('success')): ?>
                <div class="alert text-white bg-success" role="alert">
                    <div class="iq-alert-text"><?php echo e(session('success')); ?></div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="ri-close-line"></i>
                    </button>
                </div>
            <?php endif; ?>
            <div class="d-flex flex-wrap align-items-center justify-content-between mb-4">
                <div>
                    <h4 class="mb-3">Riwayat Stok <span class="badge bg-success">Masuk</span</h4>
                </div>
                <div>
                    <a href="<?php echo e(route('stock.all')); ?>" class="btn btn-danger add-list"><i class="fa-solid fa-trash me-3"></i>Clear Search</a>
                </div>
            </div>
        </div>

        <div class="col-lg-12">
            <form action="<?php echo e(route('stock.all')); ?>" method="get">
                <div class="d-flex flex-wrap align-items-center justify-content-between">
                    <div class="form-group row">
                        <label for="row" class="col-sm-3 align-self-center">Row:</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="row">
                                <option value="10" <?php if(request('row') == '10'): ?>selected="selected"<?php endif; ?>>10</option>
                                <option value="25" <?php if(request('row') == '25'): ?>selected="selected"<?php endif; ?>>25</option>
                                <option value="50" <?php if(request('row') == '50'): ?>selected="selected"<?php endif; ?>>50</option>
                                <option value="100" <?php if(request('row') == '100'): ?>selected="selected"<?php endif; ?>>100</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="search">Search:</label>
                        <div class="col-sm-8">
                            <div class="input-group">
                                <input type="text" id="search" class="form-control" name="search" placeholder="Search stock" value="<?php echo e(request('search')); ?>">
                                <div class="input-group-append">
                                    <button type="submit" class="input-group-text bg-primary"><i class="fa-solid fa-magnifying-glass font-size-20"></i></button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="col-lg-12">
            <div class="dt-responsive table-responsive mb-3">
                <table class="table mb-0">
                    <thead class="bg-white text-uppercase text-center">
                        <tr class="ligth ligth-data">
                            <th>No.</th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('stock_date', 'Tanggal Stok Masuk'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('invoice_no', 'Kode'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('supplier.name', 'Supplier'));?></th>
                            <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('sub_total', 'Subtotal'));?></th>
                        </tr>
                    </thead>
                    <tbody class="ligth-body">
                        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e((($stocks->currentPage() * 10) - 10) + $loop->iteration); ?></td>
                            <td><?php echo e(Carbon\Carbon::parse($stock->stock_date)->translatedformat('l, d F Y')); ?></td>
                            <td class="text-center">
                                <a class="badge bg-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Lihat Detail"
                                        href="<?php echo e(route('stock.Details', $stock->id)); ?>">
                                        <?php echo e($stock->invoice_no); ?>

                                </a>
                            </td>
                            <td><b><?php echo e($stock->supplier->name); ?></b> <br></td>
                            <td class="text-end"><span class="badge bg-danger">Rp <?php echo e(number_format($stock->sub_total)); ?></span></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($stocks->links()); ?>

        </div>
    </div>
    <!-- Page end  -->
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/stock/all.blade.php ENDPATH**/ ?>