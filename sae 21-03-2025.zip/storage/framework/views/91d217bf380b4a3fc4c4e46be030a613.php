<!-- Row & Pencarian -->
<form action="" method="get">
    <div class="row d-flex justify-content-between align-items-start">
        <div class="form-group col-sm-2">
            <select class="form-control" name="order_status"
                data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Status SO" onchange="this.form.submit()">
                <option selected disabled>-- Status SO --</option>
                <option value="" <?php if(request('order_status') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <?php $__currentLoopData = $orderStatus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($status); ?>" <?php echo e(request('order_status') == $status ? 'selected' : ''); ?>>
                        <?php echo e($status); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
        <div class="form-group col-sm-2">
            <select name="employee_id" id="employee_id" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Sales" onchange="this.form.submit()">
                <option selected disabled>-- Pilih Sales --</option>
                <option value="" <?php if(request('employee_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($employee->employee_id); ?>" <?php echo e(request('employee_id') == $employee->employee_id ? 'selected' : ''); ?>>
                    <?php echo e($employee->employee->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <?php endif; ?>
        <div class="form-group col-sm-2">
            <select name="invoice_no" id="invoice_no" class="form-control"
                    data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan jenis SO" onchange="this.form.submit()">
                <option selected disabled>-- Pilih Kode SO --</option>
                <option value="" <?php if(request('invoice_no') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                <option value="RO" <?php if(request('invoice_no') == 'RO'): ?> selected="selected" <?php endif; ?>>SO Reguler</option>
                <option value="HO" <?php if(request('invoice_no') == 'HO'): ?> selected="selected" <?php endif; ?>>SO HET</option>
                <option value="RS" <?php if(request('invoice_no') == 'RS'): ?> selected="selected" <?php endif; ?>>SO Reguler Online</option>
                <option value="HS" <?php if(request('invoice_no') == 'HS'): ?> selected="selected" <?php endif; ?>>SO HET Online</option>
            </select>
        </div>
        <div class="form-group col-sm">
            <input type="text" id="search" class="form-control" name="search" 
                data-bs-toggle="tooltip" data-bs-placement="top" title="Ketik untuk melakukan pencarian!"
                onblur="this.form.submit()" placeholder="Ketik disini untuk melakukan pencarian!" value="<?php echo e(request('search')); ?>">
        </div>
    </div>
</form>



<!-- Tabel Data -->
<table class="table table-hover bg-white nowrap mb-3">
    <thead>
        <tr class="text-white">
            <th width="5px">No.</th>
            <th>Tgl. Pesan</th>
            <th width="160px">No. SO</th>
            <th>Customer</th>
            <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
            <th>Sales</th>
            <?php endif; ?>
            <th>Subtotal</th>
            <th colspan="2">Diskon</th>
            <th>Grand Total</th>
            <th class="bg-primary text-white"><i class="fas fa-cog me-3"></i>Status SO</th>
            <th class="bg-warning">
                <a href="<?php echo e(route('do.all')); ?>" class="text-white">
                    <i class="fas fa-truck me-3"></i>Delivery Order
                </a>
            </th>
            <th class="bg-danger">
                <a href="<?php echo e(route('collection.all')); ?>" class="text-white">
                    <i class="fas fa-money-bill-alt me-3"></i>Collection
                </a>
            </th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?></td>
            <td>
                <span data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e(Carbon\Carbon::parse($order->order_date)->translatedformat('l, d F Y')); ?>">
                    <?php echo e(Carbon\Carbon::parse($order->order_date)->translatedformat('d M Y')); ?>

                </span>
            </td>
            <td>
                <div class="d-flex justify-content-between align-items-center">
                    <a class="badge me-2
                        <?php echo e(// $order->order_status === 'Menunggu persetujuan' ? 'bg-purple' : 
                            (strpos($order->invoice_no, '-RO') !== false ? 'bg-primary' : 
                            (strpos($order->invoice_no, '-HO') !== false ? 'bg-danger' : 
                            (strpos($order->invoice_no, '-RS') !== false ? 'bg-success' : 
                            (strpos($order->invoice_no, '-HS') !== false ? 'bg-warning' : 'bg-secondary'))))); ?>"  
                            href="<?php echo e(route('so.orderDetails', $order->id)); ?>" 
                            data-bs-toggle="tooltip" 
                            data-bs-placement="top" 
                            title="Lihat Detail Pesanan">
                            <?php echo e($order->invoice_no); ?>

                    </a>
                    <a href="<?php echo e(route('so.invoiceDownload', $order->id)); ?>"
                        class="badge bg-info"  data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak dokumen SO">
                        <i class="fas fa-print" aria-hidden="true"></i> 
                    </a>
                </div>
            </td>
            <td>
                <h6 class="mb-0"><?php echo e($order->customer->NamaLembaga); ?></h6>
                <span class="text-secondary"><?php echo e($order->customer->NamaCustomer); ?></span>
            </td>
            <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
            <th data-bs-toggle="tooltip" data-bs-placement="top" title="<?php echo e($order->customer->employee->name); ?>"><?php echo e(explode(' ', $order->customer->employee->name)[0]); ?></th>
            <?php endif; ?>
            <td class="accounting subtotal"><?php echo e(number_format($order->sub_total)); ?></td>
            <td class="accounting discountPercent"><?php echo e(number_format($order->discount_percent, 2)); ?></td>
            <td class="accounting discountRp"><?php echo e(number_format($order->discount_rp)); ?></td>
            <td class="accounting grandtotal"><?php echo e(number_format($order->grandtotal)); ?></td>
            
            <?php if($order->order_status === 'Selesai' && $order->shipping_status === 'Terkirim' && $order->payment_status === 'Lunas'): ?>
                <td colspan="3">
                    <span class="badge bg-success w-100">Transaksi Selesai</span>
                </td>
            <?php elseif($order->order_status === 'Menunggu persetujuan'): ?>
                <td colspan="3">
                    <div class="row align-middle">
                        <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin'])): ?>
                            <div class="col">
                                <a href="#" class="badge bg-warning w-100" data-bs-toggle="modal" data-bs-target="#confirmation<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>">Menunggu Persetujuan Manajer Marketing</a>
                                
                                <?php echo $__env->make('marketing.salesorder.data.status-update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                            
                        <?php else: ?>
                            <div class="col">
                                <span class="badge bg-warning w-100">Menunggu Persetujuan Manajer Marketing</span>
                            </div>
                        <?php endif; ?>
                    </div>
                </td>
            <?php elseif($order->order_status === 'Ditolak'): ?>
                <td colspan="3">
                    <span class="badge bg-danger w-100">Ditolak</span>
                </td>
            <?php elseif($order->order_status === 'Dibatalkan'): ?>
                <td colspan="3">
                    <span class="badge bg-danger w-100">Dibatalkan</span>
                </td>
            <?php else: ?>
                <!-- Status SO -->
                <td class="text-center">
                    <?php if($order->order_status === 'Disetujui' && $order->shipping_status === 'Terkirim' && $order->payment_status === 'Lunas'): ?>
                        <span data-bs-toggle="tooltip" data-bs-placement="top" title="Perbarui status menjadi SELESAI">
                            <a href="#" class="badge bg-info w-100" data-bs-toggle="modal" data-bs-target="#finished<?php echo e($order->id); ?>" data-id="<?php echo e($order->id); ?>">Disetujui</a>
                        </span>
                        <!-- modal -->
                        <?php echo $__env->make('marketing.salesorder.data.status-finished', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php else: ?> 
                        <span data-bs-toggle="tooltip" class="badge bg-primary w-100"><?php echo e($order->order_status); ?></span>
                    <?php endif; ?>
                </td>
                <!-- Status DO -->
                <td class="text-center">
                    <?php if(auth()->user()->hasAnyRole(['Super Admin', 'Manajer Marketing', 'Admin', 'Admin Gudang']) && $order->order_status === 'Disetujui' && $order->shipping_status === 'Pengiriman ke-1'): ?>
                        <div class="d-flex justify-content-between">
                            <a class="badge bg-purple-300" data-bs-toggle="tooltip" data-bs-placement="top" title="Cetak Dokumen Penyiapan Produk" data-original-title="Cetak Dokumen Penyiapan Produk"
                                href="<?php echo e(route('do.printPenyiapan', $order->id)); ?>">
                                <i class="fa fa-print me-0" aria-hidden="true"></i>
                            </a>
                            <form action="<?php echo e(route('so.shippingStatus')); ?>" method="POST" class="confirmation-form">
                                <?php echo method_field('PUT'); ?>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($order->id); ?>">
                                <input type="hidden" name="shipping_status" id="shipping_status_<?php echo e($order->id); ?>">
                            
                                <div class="btn-group">
                                    <a class="text text-primary dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <i class="fa-solid fa-truck" data-bs-toggle="tooltip" data-bs-placement="top" title="Perbarui status pengiriman"></i>
                                    </a>
                                    <div class="dropdown-menu dropdown-menu-left">
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Pengiriman ke-1')">Pengiriman ke-1</button>
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Pengiriman ke-2')">Pengiriman ke-2</button>
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Pengiriman ke-3')">Pengiriman ke-3</button>
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Pengiriman ke-4')">Pengiriman ke-4</button>
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Pengiriman ke-5')">Pengiriman ke-5</button>
                                        <button type="submit" class="dropdown-item" onclick="setShippingStatus(<?php echo e($order->id); ?>, 'Terkirim')">Terkirim</button>
                                    </div>
                                </div>
                            </form>
                    <?php endif; ?>
                            <?php if($order->shipping_status === 'Terkirim' && $order->order_status === 'Selesai'): ?>
                            <?php elseif($order->shipping_status === 'Terkirim'): ?>
                                <span data-bs-toggle="tooltip" class="badge bg-success w-100"><?php echo e($order->shipping_status); ?></span>
                            <?php else: ?>
                                <span data-bs-toggle="tooltip" class="badge bg-danger w-100"><?php echo e($order->shipping_status); ?></span>
                            <?php endif; ?>
                    </div>
                </td>
                <!-- Status Collection -->
                <td class="text-center">
                    <?php if($order->payment_status === 'Lunas'): ?>
                        <span data-bs-toggle="tooltip" class="badge bg-success w-100"><?php echo e($order->payment_status); ?></span>
                    <?php elseif($order->payment_status === 'Belum Lunas'): ?>
                        <span data-bs-toggle="tooltip" class="badge bg-warning w-100"><?php echo e($order->payment_status); ?></span>
                    <?php else: ?>
                        <span data-bs-toggle="tooltip" class="badge bg-danger w-100"><?php echo e($order->payment_status); ?></span>
                    <?php endif; ?>
                </td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($orders->links()); ?>


<!-- Rekap -->


<script src="<?php echo e(asset('assets/js/plugins/sweetalert2.all.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/pages/ac-alert.js')); ?>"></script>
<script>
    function setShippingStatus(orderId, status) {
        document.getElementById('shipping_status_' + orderId).value = status;
    }
    
    document.querySelector('.bs-radio-input').addEventListener('click', function () {
    (async () => {
      const inputOptions = new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            '#ff0000': 'Red',
            '#00ff00': 'Green',
            '#0000ff': 'Blue'
          });
        }, 1000);
      });
      const { value: color } = await Swal.fire({
        title: 'Select color',
        input: 'radio',
        inputOptions: inputOptions,
        inputValidator: (value) => {
          if (!value) {
            return 'You need to choose something!';
          }
        }
      });
      if (color) {
        Swal.fire({
          html: `You selected: ` + color
        });
      }
    })();
  });
</script>
<?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/data/table.blade.php ENDPATH**/ ?>