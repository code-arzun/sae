    <!-- Filter -->
    <form action="#" method="get">
        <div class="d-flex flex-wrap align-items-center row">
            <!-- Filter berdasarkan SO -->
                <div class="col-sm-12 mb-3">
                    <select class="form-control order_id" name="order_id"
                        data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan SO" onchange="this.form.submit()">
                        <option selected="" disabled="">-- Pilih SO --</option>
                        <option value="" <?php if(request('order_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <?php $__currentLoopData = $salesorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesorder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($salesorder->id); ?>" <?php echo e(request('order_id') == $salesorder->id ? 'selected' : ''); ?>>
                                <?php echo e($salesorder->invoice_no); ?> | <?php echo e($salesorder->customer->NamaLembaga); ?> - 
                                <?php echo e($salesorder->customer->NamaCustomer); ?> | Rp <?php echo e($salesorder->sub_total); ?> | <?php echo e($salesorder->customer->employee->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <!-- Jenjang -->
                <div class="col-sm-3 mb-3">
                    <select name="jenjang" id="jenjang" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Jenjang" onchange="this.form.submit()">
                        <option selected disabled>-- Jenjang --</option>
                        <option value="" <?php if(request('jenjang') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <option value="SD" <?php if(request('jenjang') == 'SD'): ?> selected="selected" <?php endif; ?>>SD</option>
                        <option value="SMP" <?php if(request('jenjang') == 'SMP'): ?> selected="selected" <?php endif; ?>>SMP</option>
                        <option value="SMA" <?php if(request('jenjang') == 'SMA'): ?> selected="selected" <?php endif; ?>>SMA</option>
                    </select>
                </div>
            <!-- Kelas -->
                <div class="col-sm-3 mb-3">
                    <select name="kelas" id="kelas" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kelas" onchange="this.form.submit()">
                        <option selected disabled>-- Kelas --</option>
                        <option value="" <?php if(request('kelas') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <option value="Kelas 1" <?php if(request('kelas') == 'Kelas 1'): ?> selected="selected" <?php endif; ?>>Kelas 1</option>
                        <option value="Kelas 2" <?php if(request('kelas') == 'Kelas 2'): ?> selected="selected" <?php endif; ?>>Kelas 2</option>
                        <option value="Kelas 3" <?php if(request('kelas') == 'Kelas 3'): ?> selected="selected" <?php endif; ?>>Kelas 3</option>
                        <option value="Kelas 4" <?php if(request('kelas') == 'Kelas 4'): ?> selected="selected" <?php endif; ?>>Kelas 4</option>
                        <option value="Kelas 5" <?php if(request('kelas') == 'Kelas 5'): ?> selected="selected" <?php endif; ?>>Kelas 5</option>
                        <option value="Kelas 6" <?php if(request('kelas') == 'Kelas 6'): ?> selected="selected" <?php endif; ?>>Kelas 6</option>
                        <option value="Kelas 7" <?php if(request('kelas') == 'Kelas 7'): ?> selected="selected" <?php endif; ?>>Kelas 7</option>
                        <option value="Kelas 8" <?php if(request('kelas') == 'Kelas 8'): ?> selected="selected" <?php endif; ?>>Kelas 8</option>
                        <option value="Kelas 9" <?php if(request('kelas') == 'Kelas 9'): ?> selected="selected" <?php endif; ?>>Kelas 9</option>
                        <option value="Kelas 10" <?php if(request('kelas') == 'Kelas 10'): ?> selected="selected" <?php endif; ?>>Kelas 10</option>
                        <option value="Kelas 11" <?php if(request('kelas') == 'Kelas 11'): ?> selected="selected" <?php endif; ?>>Kelas 11</option>
                        <option value="Kelas 12" <?php if(request('kelas') == 'Kelas 12'): ?> selected="selected" <?php endif; ?>>Kelas 12</option>
                    </select>
                </div>
            <!-- Kategori -->
                <div class="col-sm-3 mb-3">
                    <select name="category_id" id="category_id" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Kategori" onchange="this.form.submit()">
                        <option selected disabled>-- Kategori --</option>
                        <option value="" <?php if(request('category_id') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->category_id); ?>" <?php echo e(request('category_id') == $category->category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->category->name); ?> 
                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <!-- Mata Pelajaran -->
                <div class="col-sm-3 mb-3">
                    <select name="mapel" id="mapel" class="form-control"
                            data-bs-toggle="tooltip" data-bs-placement="top" title="Filter berdasarkan Mata Pelajaran" onchange="this.form.submit()">
                        <option selected disabled>-- Mata Pelajaran --</option>
                        <option value="" <?php if(request('mapel') == 'null'): ?> selected="selected" <?php endif; ?>>Semua</option>
                        <option value="Indonesia" <?php if(request('mapel') == 'Indonesia'): ?> selected="selected" <?php endif; ?>>Bahasa Indonesia</option>
                        <option value="Jawa" <?php if(request('mapel') == 'Jawa'): ?> selected="selected" <?php endif; ?>>Bahasa Jawa</option>
                        <option value="Inggris" <?php if(request('mapel') == 'Inggris'): ?> selected="selected" <?php endif; ?>>Bahasa Inggris</option>
                        <option value="Matematika" <?php if(request('mapel') == 'Matematika'): ?> selected="selected" <?php endif; ?>>Matematika</option>
                        <option value="IPAS" <?php if(request('mapel') == 'IPAS'): ?> selected="selected" <?php endif; ?>>IPAS</option>
                        <option value="Pancasila" <?php if(request('mapel') == 'Pancasila'): ?> selected="selected" <?php endif; ?>>Pend. Pancasila</option>
                        <option value="Islam" <?php if(request('mapel') == 'Islam'): ?> selected="selected" <?php endif; ?>>Pend. Agama Islam</option>
                        <option value="PJOK" <?php if(request('mapel') == 'PJOK'): ?> selected="selected" <?php endif; ?>>PJOK</option>
                        <option value="Rupa" <?php if(request('mapel') == 'Rupa'): ?> selected="selected" <?php endif; ?>>Seni Rupa</option>
                        <option value="Musik" <?php if(request('mapel') == 'Musik'): ?> selected="selected" <?php endif; ?>>Seni Musik</option>
                        <option value="Tari" <?php if(request('mapel') == 'Tari'): ?> selected="selected" <?php endif; ?>>Seni Tari</option>
                        <option value="Teater" <?php if(request('mapel') == 'Teater'): ?> selected="selected" <?php endif; ?>>Seni Teater</option>
                        <option value="PPKN" <?php if(request('mapel') == 'PPKN'): ?> selected="selected" <?php endif; ?>>PPKN</option>
                    </select>
                </div>
            
        </div>
    </form>
    <!-- Daftar Produk -->
    <div class="dt-responsive table-responsive mb-3 border-none">
        <table class="table nowrap mb-0">
            <thead>
                <tr>
                    <th>Nama Produk</th>
                    <th>Kategori</th>
                    <th width="100px">Harga</th>
                    <th>Dipesan</th>
                    <th>Terkirim</th>
                    <th>Dikirim</th>
                    <th>Belum dikirim</th>
                    <th>Stok</th>
                    <th>#</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <th><?php echo e($product->product_name); ?></th>
                    <td><?php echo e($product->category->name); ?></td>
                    <td class="accounting price"><?php echo e(number_format($product->selling_price)); ?></td>
                    <th class="text-center">
                        <?php if($product->filteredOrderDetail): ?>
                            
                            <span class="text-secondary"><?php echo e(number_format($product->filteredOrderDetail->quantity)); ?></span>
                        <?php endif; ?>
                    </th>
                    <th class="text-center">
                        <?php if($product->filteredOrderDetail): ?>
                            <?php if($product->filteredOrderDetail->delivered === $product->filteredOrderDetail->quantity): ?>
                                <span class="text-success"><?php echo e(number_format($product->filteredOrderDetail->delivered)); ?></span>
                            <?php elseif($product->filteredOrderDetail->delivered > 0 && $product->filteredOrderDetail->delivered < $product->filteredOrderDetail->quantity): ?>
                                <span class="text-primary"><?php echo e(number_format($product->filteredOrderDetail->delivered)); ?></span>
                            <?php else: ?>
                                
                            <?php endif; ?>
                        <?php endif; ?>
                    </th>
                    <th class="text-center">
                        <?php if($product->filteredOrderDetail): ?>
                            <?php if($product->filteredOrderDetail->sent === $product->filteredOrderDetail->quantity): ?>
                                <span class="text-success"><?php echo e(number_format($product->filteredOrderDetail->sent)); ?></span>
                            <?php elseif($product->filteredOrderDetail->sent > 0 && $product->filteredOrderDetail->sent < $product->filteredOrderDetail->quantity): ?>
                                <span class="text-primary"><?php echo e(number_format($product->filteredOrderDetail->sent)); ?></span>
                            <?php else: ?>
                                
                            <?php endif; ?>
                        <?php endif; ?>
                    </th>
                    <th class="text-center">
                        <?php if($product->filteredOrderDetail): ?>
                            <?php if($product->filteredOrderDetail->to_send === $product->filteredOrderDetail->quantity): ?>
                                <span class="text-danger"><?php echo e(number_format($product->filteredOrderDetail->to_send)); ?></span>
                            <?php elseif($product->filteredOrderDetail->to_send > 0 && $product->filteredOrderDetail->to_send < $product->filteredOrderDetail->quantity): ?>
                                <span class="text-secondary"><?php echo e(number_format($product->filteredOrderDetail->to_send)); ?></span>
                            <?php else: ?>
                                
                            <?php endif; ?>
                        <?php endif; ?>
                    </th>
                    <th class="text-center">
                        <?php if($product->product_store > 100): ?>
                            <span class="text-success"><?php echo e(number_format($product->product_store)); ?></span>
                        <?php elseif($product->product_store >= 50 && $product->product_store <= 99): ?>
                            <span class="text-warning"><?php echo e(number_format($product->product_store)); ?></span>
                        <?php else: ?>
                            <span class="text-danger"><?php echo e(number_format($product->product_store)); ?></span>
                        <?php endif; ?>
                    </th>
                    <form action="<?php echo e(route('inputdo.addCart')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                    <td>
                            <input type="hidden" name="id" value="<?php echo e($product->id); ?>">
                            <input type="hidden" name="name" value="<?php echo e($product->product_name); ?>">
                            <input type="hidden" name="category" value="<?php echo e($product->category->name); ?>">
                            <input type="hidden" name="price" value="<?php echo e($product->selling_price); ?>">
                            <?php if($product->product_store > 0 && optional($product->filteredOrderDetail)->delivered < optional($product->filteredOrderDetail)->quantity): ?>
                                <button type="submit" class="btn btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Tambah ke daftar pesanan"><i class="ti ti-plus"></i></button>
                            <?php else: ?>
                            <?php endif; ?>
                        </td>
                    </form>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="alert text-white bg-danger" role="alert">
                    <div class="iq-alert-text">Data tidak ditemukan!</div>
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <i class="ri-close-line"></i>
                    </button>
                </div>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($products->links()); ?><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/warehouse/delivery/input/product.blade.php ENDPATH**/ ?>