<table class="table">
    <thead>
        <tr>
            <th width="50px">#</th>
            <th>Nama Produk</th>
            <th width="120px">Harga</th>
            <th width="50px">Jumlah</th>
            <th width="150px">Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $productItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center">
                <a href="<?php echo e(route('inputso.deleteCart', $item->rowId)); ?>" class="btn btn-danger" data-bs-toggle="tooltip" data-bs-placement="left" title="Hapus">
                    <i class="ti ti-trash"></i>
                </a>
            </td>
            <td>
                <h5 class="mb-0"><?php echo e($item->name); ?></h5>
                <span class="text-secondary"><?php echo e($item->category); ?></span>
            </td>
            <td class="accounting price"><?php echo e(number_format($item->price)); ?></td>
            <form action="<?php echo e(route('inputso.updateCart', $item->rowId)); ?>" method="POST">
            <td>
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <input type="number" class="form-control text-center" style="width:100px" name="qty" required
                            value="<?php echo e(old('qty', $item->qty)); ?>" onblur="this.form.submit()">
                    </div>
                </td>
            </form>
            <td class="accounting price"><?php echo e(number_format($item->subtotal)); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<!-- Total -->
<table class="table nowrap">
    <tr>
        <th>
            <div class="d-flex justify-content-start">
                <span class="me-3">Total Item</span>
                <span class="badge bg-info"><?php echo e(number_format(count(Cart::content()))); ?></span>
            </div>
        </th>
        <th>
            <div class="d-flex justify-content-center">
                <span class="me-3">Total Barang</span>
                <span class="badge bg-warning"><?php echo e(number_format(Cart::count())); ?></span>
            </div>
        </th>
        <th>
            <div class="d-flex justify-content-end">
                <span class="me-3">Subtotal</span>
                <span class="badge bg-success">Rp <?php echo e(number_format(Cart::subtotal())); ?></span>
                <span id="subtotal" hidden><?php echo e(Cart::subtotal()); ?></span>
            </div>
        </th>
    </tr>
    <!-- Diskon -->
    <form action="<?php echo e(route('inputso.confirmation')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <tr>
            <th class="text-end" data-bs-toggle="tooltip" data-bs-placement="top" title="Gunakan titik (.) sebagai pemisah!">Diskon (%)</th>
            <th>
                <div class="input-group">
                    <input type="number" step="0.01" data-bs-toggle="tooltip" data-bs-placement="top" title="Gunakan titik (.) sebagai pemisah!"
                        onclick="calculateDiscount()" onkeyup="calculateDiscount()" class="form-control text-center"
                        id="discount_percent" name="discount_percent" value="<?php echo e(old('discount_percent', 0)); ?>">
                </div>
            </th>
            <th>
                <input type="number" class="form-control text-center bg-white" id="discount_rp" name="discount_rp" value="<?php echo e(old('discount_rp', 0)); ?>" readonly>
            </th>
        </tr>
    <!-- Grand Total -->
    <tr>
        <th colspan="2" class="text-end">Grand Total</th>
        <th>
            <input type="number" class="form-control bg-white text-center" id="grandtotal" name="grandtotal" value="<?php echo e(old('grandtotal', 0)); ?>" readonly>
        </th>
        
    </tr>
</table>

<div class="col-md-12 mt-3">
    <div class="form-group">
        <label for="customer_id">Pilih Customer</label>
        <select class="form-control select2" id="customer_id" name="customer_id" required>
            <option selected="" disabled="">-- Customer --</option>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($customer->id); ?>" 
                        data-nama-lembaga="<?php echo e($customer->NamaLembaga); ?>"
                        data-nama-customer="<?php echo e($customer->NamaCustomer); ?>"
                        data-jabatan="<?php echo e($customer->Jabatan); ?>"
                        <?php if(auth()->user()->hasAnyRole('Super Admin', 'Manajer Marketing', 'Admin')): ?>
                        data-employee-name="<?php echo e($customer->employee->name); ?>"
                        <?php endif; ?>>
                    <?php echo e($customer->NamaLembaga); ?> | <?php echo e($customer->NamaCustomer); ?> - <?php echo e($customer->Jabatan); ?>

                    <?php if(auth()->user()->hasAnyRole('Super Admin', 'Manajer Marketing', 'Admin')): ?>
                    | <?php echo e($customer->employee->name); ?>

                    <?php endif; ?>
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <?php $__errorArgs = ['customer_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback">
            <?php echo e($message); ?>

        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="col-md-12 mt-3">
    <button type="submit" class="btn btn-success w-100"><b>Buat Sales Order</b></button>
</div>
</form><?php /**PATH I:\-Code-\laragon\www\sae\resources\views/marketing/salesorder/input/cart.blade.php ENDPATH**/ ?>