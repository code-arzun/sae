<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>CV. SAE GROUP</title>
    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/backend-plugin.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/remixicon/fonts/remixicon.css')); ?>">
</head>
<body>
    <div class="wrapper">
        <div class="container">
            <div class="row no-gutters height-self-center">
                <div class="col-sm-12 text-center align-self-center">
                    <div class="iq-error position-relative">
                        <h2 class="mb-0 mt-4">404</h2>
                        <p>Oops! Halaman tidak ditemukan.</p>
                        <a class="btn btn-primary d-inline-flex align-items-center mt-3" href="<?php echo e(route('dashboard')); ?>"><i class="ri-home-4-line"></i>Back to Home</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
<?php /**PATH I:\-Code-\laragon\www\sae\resources\views/errors/404.blade.php ENDPATH**/ ?>